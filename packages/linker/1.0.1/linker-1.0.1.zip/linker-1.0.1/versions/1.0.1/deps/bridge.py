"""
bridge.py
=========
Bridge unico del modulo `linker` de Tesseract. Vive en deps/ de la version
1.0.0 de la libreria linker.

DOS RUTAS PARA CODIGO EXTERNO
──────────────────────────────
  A) PRECOMPILADO   .so / .dll / .dylib   → libffi          (_FFIBridge)   ← FOCO ACTUAL
  B) CODIGO FUENTE  .c / .o               → compilado con libtcc embebido
                                             (ctypes directo contra libtcc.h,
                                             sin pip) a un .so/.dll/.dylib
                                             real, y cargado despues por la
                                             MISMA _FFIBridge de la ruta A
                                             (_CEngineBridge)
                    .py                    → mini-motor Python (_PyBridge, importlib)
                    .js                    → mini-motor JS     (_JSBridge, quickjs embebido)
                    .lua                   → mini-motor Lua    (_LuaBridge, lupa embebido)
  (B se deja preparado en el diseño pero no es la prioridad ahora)

CONVERSION DE TIPOS (compartida por AMBAS rutas)
─────────────────────────────────────────────────
Los tipos simples de Tesseract — INT, FLOAT, BOOL, STRING, POINTER, VOID —
se convierten al tipo nativo que el otro lado espera ANTES de llamar
(convert_in / convert_in_ctypes), y de vuelta a tipo simple Tesseract al
recibir el resultado (convert_out). Sin firma declarada (.define()), el
tipo se infiere del valor Python real de cada argumento (_infer_type).

COBERTURA DEL ESTANDAR LIBFFI (ruta A — precompilado)
──────────────────────────────────────────────────────
Internamente (a nivel de ABI/ctypes) se soporta ya el estandar completo:
  - Enteros con ancho y signo reales: INT8/16/32/64, UINT8/16/32/64
    (antes todo se forzaba a int64 — eso desalineaba structs y podia
    corromper la pila cuando el binario esperaba un ancho distinto).
  - Flotantes de precision simple (FLOAT32) ademas de doble (FLOAT) y
    long double (LONGDOUBLE).
  - Structs Y uniones (define_struct / define_union), anidados entre si,
    con arreglos de tamaño fijo, bitfields y control de alineacion
    (_pack_, equivalente a #pragma pack(N) de C).
  - Punteros TIPADOS (Ptr(base)) — a diferencia del POINTER generico
    (void*) que ya existia, un Ptr(base) sabe reinterpretar
    automaticamente lo que apunta (otro escalar, un struct/union, un
    arreglo) tanto al pasarlo como al leerlo de vuelta.
  - Parametros de salida / paso por referencia (Out(base, size=None)) —
    el patron de C "el llamador reserva el espacio y la funcion lo
    llena" (ej. int obtenerValor(int *out); void leer(char *buf, size_t
    n)). Encaja con el tipo TUPLA de Tesseract: si una funcion tiene
    parametros Out, call() devuelve (retorno, out1, out2, ...) — o solo
    el valor si es lo unico que hay.
  - Funciones variadicas nativas (define(..., variadic=True)): los
    argumentos extra mas alla de los declarados se infieren argumento
    por argumento en cada llamada, tal como libffi exige preparar el
    cif para variadicas (el tipo real puede cambiar de una llamada a
    otra, no se puede fijar una sola vez).
  - Carga por nombre logico de sistema (ej. "m", "ssl"), al estilo
    ctypes.util.find_library, ademas de ruta explicita.
  - Control de visibilidad de simbolos (RTLD_GLOBAL vs RTLD_LOCAL) para
    cuando un precompilado depende de simbolos de otro ya cargado.
  - Dependencias NATIVAS reales: linker_load_deps() ahora tambien
    precarga con RTLD_GLOBAL cualquier .so/.dylib que encuentre en el
    directorio de deps (Linux/macOS) y registra el directorio via
    os.add_dll_directory (Windows) — antes solo ajustaba sys.path/
    NODE_PATH para las rutas Python/JS, pero un .so que a su vez
    depende de OTRO .so no resolvia sus simbolos transitivos.
  - errno / GetLastError: las librerias se cargan con
    use_errno/use_last_error activados y hay un lastError() que
    devuelve {"errno": ..., "message": ...} (dict, tipo estandar).

Lo que NO esta implementado a proposito en esta version:
  - Callbacks / punteros a funcion HACIA Python (closures de libffi,
    ej. pasar una funcion Tesseract para que el binario la invoque como
    en qsort). Se dejo fuera por ahora; ver explicacion aparte de como
    aplicarlo cuando se retome.

TODO LO ANTERIOR SE VE HACIA AFUERA IGUAL DE SIMPLE
─────────────────────────────────────────────────────
Sin importar que tan especifico sea el tipo interno (int8, uint32,
float32, un union, un puntero tipado...), lo que le llega de vuelta al
interprete de Tesseract SIEMPRE se reduce a sus tipos ya existentes:
int, float, string, bool, array (list), dict, tuple. 'range' no aplica
aqui — un binario no puede devolver una convencion que solo existe del
lado del interprete.
"""

import ctypes
import ctypes.util
import copy
import importlib.util
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from typing import Any, Optional

_DEPS_DIR = Path(__file__).parent


# ════════════════════════════════════════════════════════════════════════
#  CONSTANTES DE TIPO TESSERACT  (linker.INT, linker.FLOAT, ...)
# ════════════════════════════════════════════════════════════════════════

LINKER_INT     = 0
LINKER_FLOAT   = 1
LINKER_STRING  = 2
LINKER_POINTER = 3
LINKER_VOID    = 4
LINKER_BOOL    = 5
LINKER_WSTRING = 6   # string "ancho" (UTF-16 / wchar_t*) — de cara a Tesseract
                     # sigue siendo un string normal (mismo str de Python
                     # entra y sale), solo cambia qué tipo ctypes usa por
                     # dentro para hablar con el binario.

# ── Anchos/signos reales (para que el ABI real del binario quede exacto:
#    structs bien alineados, funciones que esperan un tamaño especifico).
#    De cara a Tesseract, TODOS estos se ven y se devuelven igual que INT
#    o FLOAT — la distincion de ancho es puramente interna/ABI.
LINKER_INT8        = 7
LINKER_INT16       = 8
LINKER_INT32       = 9
LINKER_INT64       = 10  # alias explicito de LINKER_INT (mismo ancho)
LINKER_UINT8       = 11
LINKER_UINT16      = 12
LINKER_UINT32      = 13
LINKER_UINT64      = 14
LINKER_FLOAT32     = 15  # precision simple (float de C)
LINKER_LONGDOUBLE  = 16  # long double de C
LINKER_COMPLEX64   = 17  # float _Complex de C (dos float: real, imag)
LINKER_COMPLEX128  = 18  # double _Complex de C (dos double: real, imag)

# LINKER_ENUM: un enum de C NO es un tipo de ancho fijo universal — GCC
# lo achica al tipo mas chico que entra segun los valores declarados
# (salvo -fshort-enums desactivado, que es el default), MSVC SIEMPRE usa
# 'int' (4 bytes con signo) salvo un 'enum class : tipo' explicito de
# C++11. No hace falta un ctype nuevo para esto: 'enum' es semanticamente
# un LINKER_INT (el default sano, valido para MSVC y para GCC sin
# -fshort-enums). Para el caso -fshort-enums de GCC (enum mas chico que
# int), ya alcanza con marcar el valor directamente con ._int8/._int16/
# ._int32 — no hace falta una marca '_enum' aparte para eso, esta marca
# es solo semantica/documental para el caso comun.
LINKER_ENUM        = 19  # alias semantico de LINKER_INT (int de 4 bytes, con signo)

# Vectores SIMD PASADOS POR VALOR (no detras de un puntero — eso ya lo
# cubre Aligned). Igual que con _Complex: no hace falta un motor de
# compilacion, alcanza con un struct ctypes de N campos del MISMO tipo
# base contiguos — en la ABI System V x86-64 y AAPCS64 (ARM64), un
# agregado homogeneo de N floats/doubles del mismo tipo se clasifica
# EXACTAMENTE igual que el vector real (SSE/AVX) y viaja en el mismo
# registro vectorial. Mismo alcance/limitacion que complex: no
# garantizado fuera de esas arquitecturas (libffi tampoco lo garantiza
# ahi con tipo nativo).
LINKER_VEC128F     = 20  # __m128  (4 x float, 128 bits)
LINKER_VEC128D     = 21  # __m128d (2 x double, 128 bits)
LINKER_VEC256F     = 22  # __m256  (8 x float, 256 bits)
LINKER_VEC256D     = 23  # __m256d (4 x double, 256 bits)


class _CComplex64(ctypes.Structure):
    _fields_ = [("real", ctypes.c_float), ("imag", ctypes.c_float)]


class _CComplex128(ctypes.Structure):
    _fields_ = [("real", ctypes.c_double), ("imag", ctypes.c_double)]


def _make_vec_struct(name, base_ctype, n):
    """Arma una ctypes.Structure de N campos ('v0'..'vN-1') del mismo
    tipo base — el layout de memoria de un vector SIMD homogeneo, sin
    necesitar ningun tipo especial de ctypes (que no expone __m128/
    __m256 directamente)."""
    fields = [(f"v{i}", base_ctype) for i in range(n)]
    return type(name, (ctypes.Structure,), {"_fields_": fields})


_CVec128F = _make_vec_struct("_CVec128F", ctypes.c_float, 4)
_CVec128D = _make_vec_struct("_CVec128D", ctypes.c_double, 2)
_CVec256F = _make_vec_struct("_CVec256F", ctypes.c_float, 8)
_CVec256D = _make_vec_struct("_CVec256D", ctypes.c_double, 4)


_CTYPE_MAP = {
    LINKER_INT:         ctypes.c_int64,
    LINKER_FLOAT:       ctypes.c_double,
    LINKER_STRING:      ctypes.c_char_p,
    LINKER_POINTER:     ctypes.c_void_p,
    LINKER_BOOL:        ctypes.c_bool,
    LINKER_WSTRING:     ctypes.c_wchar_p,
    LINKER_VOID:        None,
    LINKER_INT8:        ctypes.c_int8,
    LINKER_INT16:       ctypes.c_int16,
    LINKER_INT32:       ctypes.c_int32,
    LINKER_INT64:       ctypes.c_int64,
    LINKER_UINT8:       ctypes.c_uint8,
    LINKER_UINT16:      ctypes.c_uint16,
    LINKER_UINT32:      ctypes.c_uint32,
    LINKER_UINT64:      ctypes.c_uint64,
    LINKER_FLOAT32:     ctypes.c_float,
    LINKER_LONGDOUBLE:  ctypes.c_longdouble,
    LINKER_COMPLEX64:   _CComplex64,
    LINKER_COMPLEX128:  _CComplex128,
    LINKER_ENUM:        ctypes.c_int32,
    LINKER_VEC128F:     _CVec128F,
    LINKER_VEC128D:     _CVec128D,
    LINKER_VEC256F:     _CVec256F,
    LINKER_VEC256D:     _CVec256D,
}

# Layout de memoria de un _Complex de C: dos campos del mismo tipo base
# (real, imaginario) contiguos — es lo que exige el estandar, no hace
# falta ningun motor de compilacion para representarlo, alcanza con un
# struct de dos campos (_CComplex64/_CComplex128 arriba).
_COMPLEX_TYPES = {LINKER_COMPLEX64, LINKER_COMPLEX128}

# Vectores SIMD por valor — mismo criterio que _COMPLEX_TYPES, agregado
# aparte para no tocar el camino de complex ya validado.
_VECTOR_TYPES = {LINKER_VEC128F, LINKER_VEC128D, LINKER_VEC256F, LINKER_VEC256D}

# Especificacion de cada tipo "grupo" (complex o vector): (kind string
# para _ffi_kind, cantidad de componentes, nombres de campo en el ctype).
_GROUP_SPECS = {
    LINKER_COMPLEX64:  ('complex64',  2, ('real', 'imag')),
    LINKER_COMPLEX128: ('complex128', 2, ('real', 'imag')),
    LINKER_VEC128F:    ('vec128f',    4, tuple(f'v{i}' for i in range(4))),
    LINKER_VEC128D:    ('vec128d',    2, tuple(f'v{i}' for i in range(2))),
    LINKER_VEC256F:    ('vec256f',    8, tuple(f'v{i}' for i in range(8))),
    LINKER_VEC256D:    ('vec256d',    4, tuple(f'v{i}' for i in range(4))),
}
_GROUP_TYPES = _COMPLEX_TYPES | _VECTOR_TYPES

# Grupos de "simplificacion de salida": sin importar el ancho/signo real
# usado para el ABI, todo entero vuelve como int de Python y todo
# flotante como float de Python — son los unicos tipos que Tesseract
# reconoce, nunca sus subtipos de ancho fijo.
_INT_TYPES   = {LINKER_INT, LINKER_INT8, LINKER_INT16, LINKER_INT32, LINKER_INT64,
                LINKER_UINT8, LINKER_UINT16, LINKER_UINT32, LINKER_UINT64, LINKER_ENUM}
_FLOAT_TYPES = {LINKER_FLOAT, LINKER_FLOAT32, LINKER_LONGDOUBLE}

_FFI_EXTS   = {'.so', '.dll', '.dylib', 'a'}
_C_SRC_EXTS = {'.c', '.o'}


class LinkerError(RuntimeError):
    pass


# ════════════════════════════════════════════════════════════════════════
#  MARCADORES DE TIPO — punteros tipados y parametros de salida
# ════════════════════════════════════════════════════════════════════════

class Ptr:
    """
    Puntero TIPADO a otro tipo (primitivo, struct/union por nombre, o
    arreglo (tipo,largo)) — a diferencia de LINKER_POINTER (void* ciego),
    Ptr(base) sabe reinterpretar automaticamente lo que apunta, tanto al
    pasarlo (arma la instancia real y toma su direccion) como al leerlo
    de vuelta (lo desreferencia y lo convierte a dict/lista/escalar).

    Uso tipico: un campo de struct que apunta a otro struct (listas
    enlazadas, arboles), o el tipo de retorno de una funcion que
    devuelve 'struct Foo *' en vez de 'struct Foo' por valor.

    NO se usa para callbacks (puntero a funcion hacia Python) — eso no
    esta soportado en esta version.
    """
    __slots__ = ("base",)

    def __init__(self, base):
        self.base = base

    def __repr__(self):
        return f"Ptr({self.base!r})"


class Out:
    """
    Marca un argumento como parametro de SALIDA / paso por referencia
    (el patron de C "el llamador reserva el espacio, la funcion lo
    llena"): int obtenerValor(int *out); void leerBuffer(char *buf,
    size_t n).

    base: tipo real que la funcion va a escribir ahi (primitivo, nombre
    de struct/union, o (tipo,largo) para arreglos).
    size: SOLO obligatorio (con valor razonable) para STRING/WSTRING —
    C necesita saber cuanta memoria reservar para el buffer que el
    binario va a llenar. Para escalares/structs no aplica (el tamaño ya
    lo da el propio tipo).

    Un mismo call() puede tener varios Out(...). El valor de retorno de
    call() pasa a ser una TUPLA (retorno_normal_si_no_es_void, out1,
    out2, ...) — o el valor suelto si solo hay una cosa que devolver.
    Sigue siendo uno de los tipos ya estandarizados del interprete.
    """
    __slots__ = ("base", "size")

    def __init__(self, base, size: Optional[int] = None):
        self.base = base
        self.size = int(size) if size else None

    def __repr__(self):
        return f"Out({self.base!r}, size={self.size!r})"


class Aligned:
    """
    Marca un argumento como PUNTERO a una instancia de 'base' reservada
    en una dirección de memoria forzada a un múltiplo de 'align' bytes
    (16 para SSE, 32 para AVX, etc.) — el caso de un tipo vectorial
    (__m128/__m256) que viaja detrás de un puntero en la firma de una
    función C, algo mucho más común en APIs públicas que recibirlo por
    valor directo.

    ctypes no expone una forma portable de forzar alineación hacia
    ARRIBA sobre un Structure/array común, así que se resuelve a mano:
    se reserva un bloque un poco más grande del necesario y se recorta
    hasta la primera dirección alineada dentro de ese bloque — funciona
    igual en cualquier plataforma, sin depender de versión de ctypes.

    Solo válido como tipo de ARGUMENTO en define() (igual que Out) — no
    dentro de defineStruct()/defineUnion(), ni como tipo de retorno.
    """
    __slots__ = ("base", "align")

    def __init__(self, base, align: int = 16):
        self.base = base
        self.align = int(align)

    def __repr__(self):
        return f"Aligned({self.base!r}, align={self.align!r})"


class Callback:
    """
    Marca un tipo (retorno de define(), o campo de defineStruct()) como
    PUNTERO A FUNCIÓN con esta firma exacta — el sentido CONTRARIO a
    pasar una función Tesseract como callback hacia C: aquí es el binario
    quien ENTREGA un puntero a función (ej. una fábrica que devuelve un
    manejador, o una tabla de funciones/vtable) y Tesseract lo recibe ya
    listo para invocarlo.

    ret_type / arg_types: la firma C exacta del puntero (mismos tipos que
    acepta define(): primitivos, Ptr(...), nombre de struct/union, etc.)

    El valor que llega a Tesseract es un NativeCallback (ver más abajo),
    invocable con .fn(args) — NO con 'miPuntero(args)' directo: esa
    sintaxis solo reconoce funciones DECLARADAS de Tesseract; extenderla
    a esto sería un cambio aparte en la resolución de llamadas del
    intérprete.
    """
    __slots__ = ("ret_type", "arg_types")

    def __init__(self, ret_type, arg_types):
        self.ret_type = ret_type
        self.arg_types = list(arg_types)

    def __repr__(self):
        return f"Callback({self.ret_type!r}, {self.arg_types!r})"


class NativeCallback:
    """
    Envoltorio invocable de un puntero a función que un binario DEVOLVIÓ
    (via Callback(...) como tipo de retorno o de campo de struct). Se usa
    con .fn(args), igual que un LinkerObject:

        var fabricaDeManejadores = dep.fn("obtenerManejador");
        var resultado = fabricaDeManejadores.fn(42);

    Si el binario devolvió NULL, el valor completo ya es None/null — este
    envoltorio solo existe cuando el puntero es real.
    """
    __slots__ = ("_c_func", "_ret_type", "_arg_types")

    def __init__(self, c_func, ret_type, arg_types):
        self._c_func = c_func
        self._ret_type = ret_type
        self._arg_types = arg_types

    def fn(self, *args) -> Any:
        if len(args) == 1 and isinstance(args[0], list):
            args = args[0]
        c_args = [convert_in_ctypes(a, t) for a, t in zip(args, self._arg_types)]
        result = self._c_func(*c_args)
        return convert_out(result, self._ret_type)

    def __repr__(self):
        return f"<puntero nativo invocable: retorno={self._ret_type!r} args={self._arg_types!r}>"


# ════════════════════════════════════════════════════════════════════════
#  CAPA DE CONVERSION DE TIPOS — usada por TODOS los bridges por igual
# ════════════════════════════════════════════════════════════════════════

# ── Puente con los atributos '.attr' de interpre.py (ej. x._int32,
#    y._float32, arr.pointer) — Tesseract puede "marcar" un valor con la
#    variante nativa exacta que quiere ser para libffi (ver el bloque
#    "ATRIBUTOS DE TIPO PARA LIBFFI" agregado en interpre.py). El valor
#    en si sigue siendo un int/float/str/list/dict/tuple normal (hereda
#    del tipo base), solo trae un atributo extra '_ffi_kind' con el
#    nombre de la variante. Esto se detecta por DUCK TYPING
#    (getattr(value, '_ffi_kind', None)) — bridge.py NO importa interpre.py
#    para esto, para no crear una dependencia circular ni acoplar los dos
#    modulos mas de lo necesario.
#
#    Una firma explicita declarada con .define() SIEMPRE tiene prioridad
#    sobre estas marcas — son solo para cuando NO se declaro una firma
#    (el camino de inferencia automatica).
_FFI_KIND_TO_LINKER = {
    'int8': LINKER_INT8, 'int16': LINKER_INT16, 'int32': LINKER_INT32, 'int64': LINKER_INT64,
    'uint8': LINKER_UINT8, 'uint16': LINKER_UINT16, 'uint32': LINKER_UINT32, 'uint64': LINKER_UINT64,
    'float32': LINKER_FLOAT32, 'float64': LINKER_FLOAT, 'longdouble': LINKER_LONGDOUBLE,
    'complex64': LINKER_COMPLEX64, 'complex128': LINKER_COMPLEX128,
    'enum': LINKER_ENUM,
    'vec128f': LINKER_VEC128F, 'vec128d': LINKER_VEC128D,
    'vec256f': LINKER_VEC256F, 'vec256d': LINKER_VEC256D,
    'string': LINKER_STRING, 'wstring': LINKER_WSTRING,
    'bool': LINKER_BOOL, 'void': LINKER_VOID,
    'pointer': LINKER_POINTER,
}

# ── Puente con los tipos DECLARADOS de una función Tesseract (para armar
#    callbacks reales: ver _build_native_callback más abajo). Estos son
#    los nombres que trae 'int function fn()', 'array function rr()',
#    'object function att()', etc. — distinto de _FFI_KIND_TO_LINKER, que
#    traduce las MARCAS puestas a mano (._int32, .pointer...). Un tipo
#    declarado 'dynamic'/'inferred'/'any' (retorno sin anotar, ej. la
#    'function myfunc()' genérica) no tiene un ancho de C obvio — se
#    asume LINKER_INT por defecto (el mismo criterio que ya usa
#    _infer_type para cualquier valor sin marca), y queda disponible
#    forzar algo más preciso marcando la propia referencia con un
#    atributo (ej. myfunc()._float32) que SÍ tiene prioridad sobre esto.
_TESS_TYPE_TO_LINKER = {
    'int': LINKER_INT, 'float': LINKER_FLOAT, 'string': LINKER_STRING,
    'bool': LINKER_BOOL, 'void': LINKER_VOID,
    'array': LINKER_POINTER, 'dict': LINKER_POINTER, 'tuple': LINKER_POINTER,
    'object': LINKER_POINTER, 'range': LINKER_POINTER,
}


def _is_function_ref(value: Any) -> bool:
    """
    True si 'value' es una referencia a función de Tesseract obtenida con
    'nombreFuncion(...).algo' (ver _FunctionPointerRef en interpre.py) —
    detectado por duck typing (nunca se importa interpre.py desde aquí):
    trae un 'invoke' invocable, además de 'param_types'/'return_type'.
    Esto es lo que separa una referencia a función de un valor cualquiera
    marcado con '_ffi_kind' (que no tiene 'invoke').
    """
    return (callable(getattr(value, 'invoke', None))
            and hasattr(value, 'param_types')
            and hasattr(value, 'return_type'))


def _ffi_kind_of(value: Any) -> Optional[str]:
    """'_ffi_kind' del valor si lo trae (marcado desde Tesseract via
    .attr), o None si es un valor comun y corriente."""
    return getattr(value, '_ffi_kind', None)


def _complex_pair_kind(value: Any) -> Optional[str]:
    """
    complex64/complex128 no es un envoltorio propio (nada de dict): se
    arma con una tupla/lista comun (real, imag) donde son los DOS
    ELEMENTOS (no la tupla en si) los que traen la marca _ffi_kind
    ('complex64'/'complex128'), puesta a mano en Tesseract con
    re._complex64, im._complex64 (ver ATRIBUTOS DE TIPO PARA LIBFFI en
    interpre.py, tabla de 'int'/'float'). Devuelve ese kind si el par
    coincide, o None si no aplica (tupla/lista comun, sin marca).
    """
    if isinstance(value, (tuple, list)) and len(value) == 2:
        k0 = _ffi_kind_of(value[0])
        if k0 in ('complex64', 'complex128') and _ffi_kind_of(value[1]) == k0:
            return k0
    return None


_VECTOR_KINDS = {'vec128f': 4, 'vec128d': 2, 'vec256f': 8, 'vec256d': 4}


def _vector_group_kind(value: Any) -> Optional[str]:
    """
    Mismo criterio que _complex_pair_kind, generalizado a N componentes:
    un vector SIMD por valor (__m128/__m256) tampoco tiene envoltorio
    propio — es una tupla/lista de N numeros donde TODOS sus elementos
    traen la misma marca _ffi_kind ('vec128f'/'vec128d'/'vec256f'/
    'vec256d'), puesta a mano con x._vec128f, etc. sobre cada
    componente. Se mantiene separada de _complex_pair_kind (no
    fusionadas) para no tocar el camino de complex ya validado.
    """
    if not isinstance(value, (tuple, list)):
        return None
    for kind, n in _VECTOR_KINDS.items():
        if len(value) == n and all(_ffi_kind_of(el) == kind for el in value):
            return kind
    return None


def _infer_type(value: Any) -> int:
    kind = _ffi_kind_of(value)
    if kind is not None:
        tc = _FFI_KIND_TO_LINKER.get(kind)
        if tc is not None:
            return tc
    if isinstance(value, bool):    return LINKER_BOOL
    if isinstance(value, complex): return LINKER_COMPLEX128
    pair_kind = _complex_pair_kind(value)
    if pair_kind is not None:
        return _FFI_KIND_TO_LINKER[pair_kind]
    vec_kind = _vector_group_kind(value)
    if vec_kind is not None:
        return _FFI_KIND_TO_LINKER[vec_kind]
    if isinstance(value, int):     return LINKER_INT
    if isinstance(value, float):   return LINKER_FLOAT
    if isinstance(value, str):     return LINKER_STRING
    return LINKER_POINTER


def _infer_arg_spec(value: Any):
    """
    Como _infer_type, pero para el 'None = inferir este argumento' de
    define() (ver call()) — reconoce ADEMÁS las marcas 'pointer'/'out' en
    escalares y devuelve un Ptr(...)/Out(...) real en vez de un código
    escalar plano. Sin esto, un argumento marcado '.out' bajo un slot
    'None' se pasaba por VALOR en vez de por DIRECCIÓN — y la función C
    (que espera un puntero para escribir ahí) interpretaba ese valor como
    una dirección de memoria y escribía en cualquier lado: segfault real,
    confirmado. Los agregados (array/dict/tupla) NO se cubren aquí (no
    hay forma segura de re-derivar su forma exacta sin defineStruct()) —
    para esos, seguí usando defineStruct() + Out()/Ptr() explícitos.
    """
    kind = _ffi_kind_of(value)
    if kind in ('pointer', 'out') and not isinstance(value, (list, dict, tuple)):
        if isinstance(value, str):     base_tc = LINKER_STRING
        elif isinstance(value, bool):  base_tc = LINKER_BOOL
        elif isinstance(value, int):   base_tc = LINKER_INT
        elif isinstance(value, float): base_tc = LINKER_FLOAT
        else:                          base_tc = LINKER_POINTER
        return Out(base_tc) if kind == 'out' else Ptr(base_tc)
    return _infer_type(value)


def convert_in(value: Any, type_code: Optional[int] = None):
    tc = _infer_type(value) if type_code is None else type_code
    if tc in _INT_TYPES:    return int(value)
    if tc in _FLOAT_TYPES:  return float(value)
    if tc == LINKER_BOOL:   return bool(value)
    if tc in (LINKER_STRING, LINKER_WSTRING): return str(value)
    return value


def convert_in_ctypes(value: Any, type_code: Optional[int] = None):
    tc = _infer_type(value) if type_code is None else type_code
    if tc in _INT_TYPES:    return _CTYPE_MAP.get(tc, ctypes.c_int64)(int(value))
    if tc in _FLOAT_TYPES:  return _CTYPE_MAP.get(tc, ctypes.c_double)(float(value))
    if tc == LINKER_BOOL:   return ctypes.c_bool(bool(value))
    if tc == LINKER_STRING: return str(value).encode('utf-8')
    if tc == LINKER_WSTRING: return str(value)   # ctypes.c_wchar_p acepta str de Python tal cual
    if tc in _COMPLEX_TYPES:
        z = _to_py_complex(value)
        return _CTYPE_MAP[tc](z.real, z.imag)
    if tc in _VECTOR_TYPES:
        comps = _to_py_vector(value, tc)
        return _CTYPE_MAP[tc](*comps)
    return value


def convert_out(value: Any, type_code: int = LINKER_VOID):
    if type_code == LINKER_VOID or value is None:
        return None
    if type_code == LINKER_STRING and isinstance(value, bytes):
        return value.decode('utf-8', errors='replace')
    if type_code == LINKER_WSTRING:
        return value  # c_wchar_p ya entrega str de Python
    if type_code == LINKER_BOOL:   return bool(value)
    if type_code in _INT_TYPES:    return int(value)
    if type_code in _FLOAT_TYPES:  return float(value)
    if type_code in _COMPLEX_TYPES: return _from_c_complex(value, type_code)
    if type_code in _VECTOR_TYPES:  return _from_c_vector(value, type_code)
    return value


class _FFITagFloat(float):
    """
    float marcado con su '_ffi_kind' — replica local y minima de la clase
    homonima de interpre.py. NO se importa interpre.py aca a proposito
    (misma razon de siempre: evitar dependencia circular entre los dos
    modulos); se define de nuevo, chiquita, solo para poder retaguear
    real/imag al volver de una llamada nativa, de forma que ese par
    siga siendo reconocido como complex64/128 si se reenvia tal cual a
    otra llamada (ver _complex_pair_kind arriba).
    """
    def __new__(cls, value, kind):
        obj = float.__new__(cls, value)
        obj._ffi_kind = kind
        return obj


_COMPLEX_KIND_OF_CODE = {LINKER_COMPLEX64: 'complex64', LINKER_COMPLEX128: 'complex128'}


def _to_py_complex(value):
    """
    Tesseract no tiene ningún literal ni tipo 'complex' propio: un
    complex NUNCA se representa con un dict (no tiene sentido envolver
    dos números en eso) — se representa con una tupla/lista posicional
    (real, imag), o con un complex real de Python si algo llama al
    bridge directamente desde Python. Un escalar solo (int/float, ya sea
    plano o marcado con ._complex64/._complex128) se toma como la parte
    real con imaginario 0.
    """
    if isinstance(value, complex):
        return value
    if isinstance(value, (tuple, list)) and len(value) == 2:
        return complex(value[0], value[1])
    return complex(value)


def _from_c_complex(c_value, type_code):
    """
    Devuelve el _Complex de C como tupla (real, imag) — NUNCA como dict —
    con cada componente marcado con el mismo _ffi_kind ('complex64' o
    'complex128' segun type_code), para que el par siga identificandose
    como complex si se reenvia tal cual a otra llamada nativa.
    """
    kind = _COMPLEX_KIND_OF_CODE[type_code]
    return (_FFITagFloat(float(c_value.real), kind),
            _FFITagFloat(float(c_value.imag), kind))


def _to_py_vector(value, type_code):
    """
    Igual criterio que _to_py_complex, pero para vectores SIMD por valor
    (__m128/__m128d/__m256/__m256d): NUNCA dict. Se espera una tupla/
    lista de exactamente N componentes (N segun type_code) — un escalar
    solo se rellena con 0 en el resto de las posiciones (equivalente a
    "broadcast" parcial: la componente 0 es la que importa, el resto se
    completa para poder construir el struct ctypes).
    """
    kind, n, _ = _GROUP_SPECS[type_code]
    if isinstance(value, (tuple, list)):
        if len(value) == n:
            return [float(v) for v in value]
        raise LinkerError(
            f"Vector '{kind}' esperaba {n} componentes, "
            f"se recibieron {len(value)}."
        )
    return [float(value)] + [0.0] * (n - 1)


def _from_c_vector(c_value, type_code):
    """
    Devuelve el vector SIMD de C como tupla de N componentes — NUNCA
    dict — cada una marcada con su _ffi_kind ('vec128f'/'vec128d'/
    'vec256f'/'vec256d'), para que el grupo siga identificandose como
    vector si se reenvia tal cual a otra llamada nativa (ver
    _vector_group_kind).
    """
    kind, n, field_names = _GROUP_SPECS[type_code]
    return tuple(_FFITagFloat(float(getattr(c_value, fname)), kind)
                 for fname in field_names)


_PYVAL_MISSING = object()  # sentinel: "este campo no vino en el dict/tupla del usuario"


class _Signature:
    __slots__ = ("ret_type", "arg_types", "variadic", "calling_convention", "thiscall")

    def __init__(self, ret_type: int, arg_types: list, variadic: bool = False,
                 calling_convention: Optional[str] = None, thiscall: bool = False):
        self.ret_type  = ret_type
        self.arg_types = arg_types
        self.variadic  = bool(variadic)
        # None = usar la convención general del LinkerObject (self._calling_convention).
        # Si se da, esta función puntual usa OTRA convención, sin afectar al resto
        # de funciones definidas sobre la misma biblioteca.
        self.calling_convention = calling_convention
        self.thiscall = bool(thiscall)


# ════════════════════════════════════════════════════════════════════════
#  RUTA A — PRECOMPILADO:  .so / .dll / .dylib  via libffi (ctypes)
# ════════════════════════════════════════════════════════════════════════

class _FFIBridge:
    def __init__(self, path: Path, calling_convention: str = "cdecl",
                 global_symbols: bool = False):
        self._path = path
        self._sigs: dict = {}
        self._var_sigs: dict = {}   # var_name -> (type_spec, length_or_None)
        self._structs: dict = {}    # struct_o_union_name -> {"kind","fields","ctype","as_tuple"}
        self._callbacks: list = []  # mantiene vivos los ctypes.CFUNCTYPE de los callbacks — si se
                                     # recolectaran como basura, el binario quedaria con un puntero
                                     # colgante y podria crashear en cualquier momento despues.
        self._extra_libs: list = []  # [(ruta_absoluta, handle_ctypes), ...] — bibliotecas
                                      # adicionales cargadas con loadDir(), en orden de carga.
        self._keepalive: list = []  # buffers de memoria alineada (ver Aligned) que hay que
                                     # mantener vivos mientras la biblioteca esté abierta.
        self._calling_convention = calling_convention
        # ctypes SOLO sabe armar dos convenciones de llamada reales:
        # cdecl (CFUNCTYPE, la de siempre en cualquier plataforma) y
        # stdcall (WINFUNCTYPE/WinDLL, exclusiva de Windows). fastcall y
        # thiscall (las de ciertas APIs de Windows y de métodos C++
        # compilados con MSVC) NO tienen un equivalente real en ctypes —
        # no existe ningún ctypes.FASTCALLFUNCTYPE ni forma de armar ese
        # ABI desde Python puro. Fingir que "funciona" pasándolo como
        # cdecl desajustaría la pila en silencio (parámetros corridos,
        # crash o corrupción de memoria impredecible), así que se
        # rechaza con un error claro apenas se pide, en vez de simular
        # un soporte que no existe.
        if calling_convention not in ("cdecl", "stdcall"):
            raise LinkerError(
                f"Convención de llamada '{calling_convention}' no soportada.\n"
                f"  ctypes solo sabe armar 'cdecl' (por defecto, sirve para\n"
                f"  la inmensa mayoría de binarios) y 'stdcall' (WINAPI,\n"
                f"  Windows de 32 bits). 'fastcall'/'thiscall' no tienen un\n"
                f"  equivalente real en ctypes — no hay forma segura de\n"
                f"  armarlos desde Python puro sin arriesgar corrupción de\n"
                f"  memoria, así que no se simulan."
            )
        try:
            # cdecl (por defecto) sirve para la inmensa mayoría de binarios
            # en cualquier arquitectura. stdcall (WINAPI) es sobre todo
            # cosa de Windows de 32 bits — si el binario se compiló con esa
            # convención y usas CDLL de todos modos, la pila queda mal
            # ajustada y el programa truena o corrompe memoria en silencio,
            # así que se deja explícito, nunca autodetectado a ciegas.
            #
            # use_errno/use_last_error: siempre activados para poder
            # recuperar despues el estado de error del sistema (errno en
            # POSIX, GetLastError en Windows) via lastError().
            #
            # mode=RTLD_GLOBAL (global_symbols=True): expone los simbolos
            # de esta libreria al resto del proceso, para cuando OTRA
            # libreria que cargues despues necesite resolver simbolos
            # contra esta (dependencias cruzadas entre precompilados).
            # Por defecto RTLD_LOCAL (el comportamiento de siempre).
            if calling_convention == "stdcall" and sys.platform == "win32":
                self._lib = ctypes.WinDLL(str(path), use_last_error=True)
            else:
                mode = ctypes.RTLD_GLOBAL if global_symbols else ctypes.DEFAULT_MODE
                self._lib = ctypes.CDLL(str(path), mode=mode,
                                         use_errno=True, use_last_error=True)
        except OSError as e:
            raise LinkerError(
                f"Error FFI cargando '{path.name}':\n  {e}\n"
                f"  ¿Compilado para la arquitectura correcta?"
            )

    def _apply_msvc_bitfield_boundaries(self, norm_fields):
        """
        MSVC abre una unidad de almacenamiento NUEVA cada vez que el tipo
        declarado de un bitfield cambia respecto al anterior (o cuando no
        entran los bits restantes) — a diferencia de GCC/Clang, que
        siguen empaquetando en la misma unidad mientras el ANCHO EN BITS
        alcance, sin importar si el tipo declarado cambió. El bitfield
        nativo de ctypes replica el algoritmo del compilador con el que
        se compiló el propio Python (GCC en Linux/macOS, MSVC en Windows)
        — o sea que, corriendo en un host no-MSVC contra un binario
        compilado con MSVC, el layout puede no coincidir.

        Esto NO reimplementa el empaquetado de bits desde cero: solo
        inserta, entre bitfields consecutivos, un campo de RELLENO del
        tipo ANTERIOR que ocupa exactamente los bits que faltan para
        completar esa unidad — forzando el mismo punto de corte que MSVC
        aplicaría — y deja que ctypes siga haciendo el empaquetado bit a
        bit dentro de cada unidad ya delimitada (eso sí es igual en
        cualquier compilador para bitfields consecutivos del MISMO tipo).
        """
        out = []
        unit_type = None
        unit_bits = 0
        bits_used = 0
        pad_i = 0
        for (fname, ftype, flen, fbits) in norm_fields:
            is_bitfield = bool(fbits) and not flen
            if is_bitfield:
                this_unit_bits = ctypes.sizeof(self._resolve_ctype(ftype)) * 8
                needs_new_unit = (unit_type != ftype) or (bits_used + fbits > unit_bits)
                if needs_new_unit and unit_type is not None and bits_used < unit_bits:
                    out.append((f"_msvc_pad_{pad_i}", unit_type, None, unit_bits - bits_used))
                    pad_i += 1
                if needs_new_unit:
                    unit_type, unit_bits, bits_used = ftype, this_unit_bits, 0
                out.append((fname, ftype, flen, fbits))
                bits_used += fbits
            else:
                unit_type, unit_bits, bits_used = None, 0, 0
                out.append((fname, ftype, flen, fbits))
        return out

    def _apply_msvc_bitfield_boundaries(self, norm_fields):
        """
        MSVC abre una unidad de almacenamiento NUEVA cada vez que el tipo
        declarado de un bitfield cambia respecto al anterior (o cuando no
        entran los bits restantes) — a diferencia de GCC/Clang, que
        siguen empaquetando en la misma unidad mientras el ANCHO EN BITS
        alcance, sin importar si el tipo declarado cambió. El bitfield
        nativo de ctypes replica el algoritmo del compilador con el que
        se compiló el propio Python (GCC en Linux/macOS, MSVC en Windows)
        — o sea que, corriendo en un host no-MSVC contra un binario
        compilado con MSVC, el layout puede no coincidir.

        Esto NO reimplementa el empaquetado de bits desde cero: solo
        inserta, entre bitfields consecutivos, un campo de RELLENO del
        tipo ANTERIOR que ocupa exactamente los bits que faltan para
        completar esa unidad — forzando el mismo punto de corte que MSVC
        aplicaría — y deja que ctypes siga haciendo el empaquetado bit a
        bit dentro de cada unidad ya delimitada (eso sí es igual en
        cualquier compilador para bitfields consecutivos del MISMO tipo).
        """
        out = []
        unit_type = None
        unit_bits = 0
        bits_used = 0
        pad_i = 0
        for (fname, ftype, flen, fbits, falign) in norm_fields:
            is_bitfield = bool(fbits) and not flen
            if is_bitfield:
                this_unit_bits = ctypes.sizeof(self._resolve_ctype(ftype)) * 8
                needs_new_unit = (unit_type != ftype) or (bits_used + fbits > unit_bits)
                if needs_new_unit and unit_type is not None and bits_used < unit_bits:
                    out.append((f"_msvc_pad_{pad_i}", unit_type, None, unit_bits - bits_used, None))
                    pad_i += 1
                if needs_new_unit:
                    unit_type, unit_bits, bits_used = ftype, this_unit_bits, 0
                out.append((fname, ftype, flen, fbits, falign))
                bits_used += fbits
            else:
                unit_type, unit_bits, bits_used = None, 0, 0
                out.append((fname, ftype, flen, fbits, falign))
        return out

    # ── Structs / Uniones: el respaldo real de dict/tupla/arreglo sobre el ABI ──
    def _build_aggregate(self, name: str, fields: list, base_cls, pack, as_tuple,
                          bitfield_layout: str = 'native'):
        # Se registra un PLACEHOLDER antes de resolver los campos, para
        # soportar auto-referencia: un struct/union puede tener un campo
        # Ptr(su_propio_nombre) (ej. 'next' en un nodo de lista enlazada),
        # y para resolver ESE campo hace falta que el propio nombre ya
        # exista en self._structs. El layout real (_fields_) se completa
        # un paso despues — es el patron estandar de ctypes para tipos
        # auto-referenciados.
        placeholder = type(f"_TSS_{name}", (base_cls,), {})
        info = {
            "kind":     "union" if base_cls is ctypes.Union else "struct",
            "fields":   None,
            "ctype":    placeholder,
            "as_tuple": bool(as_tuple),
        }
        self._structs[name] = info

        # ── Paso 1: normalizar (nombre, tipo, longitud, bits, align) ──
        norm_fields = []
        for f in fields:
            fname = f[0]
            ftype = f[1]
            flen   = int(f[2]) if len(f) > 2 and f[2] else None
            fbits  = int(f[3]) if len(f) > 3 and f[3] else None
            falign = int(f[4]) if len(f) > 4 and f[4] else None
            if flen and fbits:
                raise LinkerError(
                    f"Campo '{fname}' de '{name}': un bitfield no puede "
                    f"ser arreglo a la vez."
                )
            if falign and fbits:
                raise LinkerError(
                    f"Campo '{fname}' de '{name}': alineación por campo no "
                    f"combina con bitfield (la alineación no aplica a nivel "
                    f"de bit, solo a nivel de byte)."
                )
            if falign and base_cls is ctypes.Union:
                # En un union TODOS los campos ya arrancan en el offset 0
                # — alinear "el campo" no tiene efecto de por sí (lo que sí
                # podría necesitar alineación extra es el UNION completo,
                # otro problema, fuera de alcance de esta marca por campo).
                falign = None
            norm_fields.append((fname, ftype, flen, fbits, falign))

        # ── Paso 2: si se pidió, forzar cortes de unidad estilo MSVC ──
        if bitfield_layout == 'msvc':
            norm_fields = self._apply_msvc_bitfield_boundaries(norm_fields)
        elif bitfield_layout != 'native':
            raise LinkerError(
                f"bitfield_layout debe ser 'native' o 'msvc', se recibió {bitfield_layout!r}."
            )

        # ── Paso 3: construir _fields_ real de ctypes, con relleno manual
        #    de bytes ANTES de cualquier campo que pida alineación propia
        #    (equivalente a __attribute__((aligned(N))) de C sobre un
        #    campo puntual). ctypes no expone alineación por campo de
        #    forma nativa (_pack_ es un único valor para TODO el struct),
        #    así que se mide el offset donde caería el campo bajo layout
        #    natural (armando, solo para medir, un struct "snapshot" con
        #    los campos acumulados hasta acá) y se inserta un filler de
        #    bytes crudos hasta el próximo múltiplo de 'falign'. Es una
        #    aproximación razonable (asume que el compilador real no
        #    reordena campos ni aplica reglas de tail-padding distintas a
        #    las de C estándar) — ante la duda, conviene confirmar contra
        #    el struct real compilado.
        ctype_fields = []
        pad_counter = 0
        for (fname, ftype, flen, fbits, falign) in norm_fields:
            base_ct = self._resolve_ctype(ftype)
            arr_ct  = base_ct * flen if flen else base_ct

            if falign and ctype_fields:
                snap = type(f"_TSS_{name}_snap{pad_counter}", (base_cls,), {})
                if pack:
                    snap._pack_ = int(pack)
                snap._fields_ = list(ctype_fields)
                current_offset = ctypes.sizeof(snap)
                remainder = current_offset % falign
                if remainder:
                    pad_size = falign - remainder
                    ctype_fields.append((f"_align_pad_{pad_counter}", ctypes.c_ubyte * pad_size))
                    pad_counter += 1

            if fbits:
                ctype_fields.append((fname, arr_ct, fbits))
            else:
                ctype_fields.append((fname, arr_ct))

        # _pack_ debe fijarse ANTES de _fields_ (asi lo exige ctypes).
        if pack:
            placeholder._pack_ = int(pack)
        placeholder._fields_ = ctype_fields
        info["fields"] = [(fname, ftype, flen, fbits) for (fname, ftype, flen, fbits, _) in norm_fields]
        return info

    def define_struct(self, struct_name: str, fields: list,
                       pack: Optional[int] = None, as_tuple: bool = False):
        """
        fields: lista de (nombre_campo, tipo, longitud=None, bits=None).
          - tipo: código primitivo (LINKER_INT/FLOAT/STRING/WSTRING/
            POINTER/BOOL o cualquiera de los anchos INT8..UINT64/
            FLOAT32/LONGDOUBLE), el nombre de OTRO struct/union ya
            definido (para anidar), o Ptr(tipo) para un campo puntero
            tipado (ej. 'siguiente' en una lista enlazada).
          - longitud: si se da, ese campo es un arreglo de 'longitud'
            elementos de 'tipo' (arreglo de primitivos, structs o Ptr).
          - bits: ancho en bits del campo (bitfield de C). Solo sobre
            tipos enteros y nunca junto con 'longitud' en el mismo campo.
        pack: fuerza la alineación del struct completo (equivalente a
          #pragma pack(N) de C). None = alineación nativa (de siempre).
        as_tuple: si True, al LEER datos este struct se entrega como
          tupla posicional en vez de dict — ambos son tipos estándar de
          Tesseract, esto solo elige cuál usar en la salida.
        Un dict de Tesseract se mapea aquí por NOMBRE de campo; una tupla
        se mapea por POSICIÓN, en el mismo orden en que se declaró.
        """
        self._structs[struct_name] = self._build_aggregate(
            struct_name, fields, ctypes.Structure, pack, as_tuple)

    def define_union(self, union_name: str, fields: list,
                      pack: Optional[int] = None, as_tuple: bool = False):
        """
        Igual que define_struct, pero para 'union' de C: todos los
        campos comparten la misma dirección de memoria (el tamaño del
        union es el del campo más grande). Útil para variantes /
        "tagged unions" que expone un precompilado.
        Nota: declarar 'bits' (bitfield) en un campo de union no tiene
        sentido real y se ignora a efectos de layout salvo que el propio
        C lo requiera; se deja disponible por si el binario lo exige.
        """
        self._structs[union_name] = self._build_aggregate(
            union_name, fields, ctypes.Union, pack, as_tuple)

    def _resolve_ctype(self, type_spec):
        """type_spec: int primitivo, str (struct/union), Ptr(base), Callback(ret,args), o (tipo, longitud)."""
        if isinstance(type_spec, Ptr):
            return ctypes.POINTER(self._resolve_ctype(type_spec.base))
        if isinstance(type_spec, Callback):
            ret_ct = None if type_spec.ret_type == LINKER_VOID else self._resolve_ctype(type_spec.ret_type)
            arg_cts = [self._resolve_ctype(t) for t in type_spec.arg_types]
            return ctypes.CFUNCTYPE(ret_ct, *arg_cts)
        if isinstance(type_spec, Out):
            raise LinkerError(
                "Out(...) solo es válido como tipo de ARGUMENTO en "
                "define(); no se usa dentro de defineStruct/defineUnion/"
                "defineVar ni como tipo de retorno."
            )
        if isinstance(type_spec, Aligned):
            raise LinkerError(
                "Aligned(...) solo es válido como tipo de ARGUMENTO en "
                "define(); no se usa dentro de defineStruct/defineUnion/"
                "defineVar ni como tipo de retorno."
            )
        if isinstance(type_spec, Aligned):
            raise LinkerError(
                "Aligned(...) solo es válido como tipo de ARGUMENTO en "
                "define(); no se usa dentro de defineStruct/defineUnion/"
                "defineVar ni como tipo de retorno."
            )
        if isinstance(type_spec, (tuple, list)):
            base, length = type_spec
            return self._resolve_ctype(base) * int(length)
        if isinstance(type_spec, str):
            info = self._structs.get(type_spec)
            if info is None:
                raise LinkerError(f"Struct/Union '{type_spec}' no definido. Usa defineStruct()/defineUnion() antes.")
            return info["ctype"]
        ct = _CTYPE_MAP.get(type_spec)
        if ct is None:
            raise LinkerError(f"Tipo no soportado: {type_spec!r}")
        return ct

    def _scalar_in(self, value, type_code):
        if type_code == LINKER_STRING:  return (str(value) if value is not None else '').encode('utf-8')
        if type_code == LINKER_WSTRING: return str(value) if value is not None else ''
        if type_code in _FLOAT_TYPES:   return float(value or 0)
        if type_code == LINKER_BOOL:    return bool(value)
        if type_code == LINKER_POINTER: return value
        if type_code in _INT_TYPES:     return int(value or 0)
        if type_code in _COMPLEX_TYPES:
            z = _to_py_complex(value if value else (0, 0))
            return _CTYPE_MAP[type_code](z.real, z.imag)
        if type_code in _VECTOR_TYPES:
            _, n, _ = _GROUP_SPECS[type_code]
            comps = _to_py_vector(value if value else [0.0] * n, type_code)
            return _CTYPE_MAP[type_code](*comps)
        return value

    def _pyval_to_cinstance(self, value, type_spec):
        """
        Convierte un dict/tupla/lista/escalar de Tesseract a su instancia
        ctypes real, según type_spec — declarado con define_struct()/
        define_union() de antemano (arreglos/structs/uniones/Ptr/Callback
        anidados incluidos).
        """
        if isinstance(type_spec, Callback):
            if value is None:
                return None
            if _is_function_ref(value):
                # Función Tesseract (miFunc(...).algo) usada como campo de
                # struct: se arma el callback real con la firma YA
                # DECLARADA aquí mismo (type_spec.ret_type/arg_types) —
                # esa es la fuente de verdad, no lo que la propia función
                # Tesseract cree que es (podrían no coincidir en ancho).
                return self._build_native_callback(
                    value, explicit_sig=(type_spec.ret_type, type_spec.arg_types))
            if isinstance(value, NativeCallback):
                # Ya es un puntero nativo recibido antes (ej. de otra
                # llamada) — se reutiliza su puntero crudo tal cual.
                return value._c_func
            return value  # puntero ctypes crudo ya armado a mano

        if isinstance(type_spec, Ptr):
            if value is None:
                return None  # ctypes traduce None a NULL para argtypes POINTER(...)
            if isinstance(value, ctypes._Pointer):
                # Ya es un puntero ctypes real (ej. armado a mano para una
                # lista enlazada / arbol, con ctypes.pointer(...) sobre
                # nodos previos) — se pasa tal cual, NO se reconstruye
                # desde cero como si fuera un dict/tupla nuevo.
                return value
            base = type_spec.base
            if isinstance(base, (str, tuple, list)):
                inner = self._pyval_to_cinstance(value, base)
                return ctypes.pointer(inner)
            base_ct = self._resolve_ctype(base)
            return ctypes.pointer(base_ct(self._scalar_in(value, base)))

        if isinstance(type_spec, (tuple, list)):
            base, length = type_spec
            length = int(length)
            arr_cls = self._resolve_ctype(type_spec)
            inst = arr_cls()
            items = list(value) if value is not None else []
            for i in range(length):
                v = items[i] if i < len(items) else None
                if isinstance(base, (str, Ptr)):
                    inst[i] = self._pyval_to_cinstance(v or {}, base)
                else:
                    inst[i] = self._scalar_in(v, base)
            return inst

        if isinstance(type_spec, str):
            info = self._structs.get(type_spec)
            if info is None:
                raise LinkerError(f"Struct/Union '{type_spec}' no definido. Usa defineStruct()/defineUnion() antes.")
            inst = info["ctype"]()
            fields = info["fields"]
            is_union = info.get("kind") == "union"
            _MISSING = _PYVAL_MISSING
            if isinstance(value, dict):
                getv = lambda fname, i: value[fname] if fname in value else _MISSING
            else:
                items = list(value) if value is not None else []
                getv = lambda fname, i: items[i] if i < len(items) else _MISSING
            for i, (fname, ftype, flen, fbits) in enumerate(fields):
                v = getv(fname, i)
                if v is _MISSING:
                    # En un UNION, todos los campos comparten la misma
                    # memoria: si el usuario no dio este campo, NO se
                    # escribe (aunque sea con un default en 0), porque
                    # eso pisaria silenciosamente el campo que si
                    # querian dejar puesto. En un STRUCT si es seguro
                    # rellenar con default, ya que cada campo tiene su
                    # propia direccion.
                    if is_union:
                        continue
                    v = None
                if flen:
                    setattr(inst, fname, self._pyval_to_cinstance(v, (ftype, flen)))
                elif isinstance(ftype, str):
                    setattr(inst, fname, self._pyval_to_cinstance(v or {}, ftype))
                elif isinstance(ftype, (Ptr, Callback)):
                    setattr(inst, fname, self._pyval_to_cinstance(v, ftype))
                else:
                    setattr(inst, fname, self._scalar_in(v, ftype))
            return inst

        return self._scalar_in(value, type_spec)

    def _ctype_to_pyval(self, c_value, type_spec):
        """
        Inverso de _pyval_to_cinstance: instancia ctypes -> dict/tupla/
        lista/escalar de Tesseract. Sin importar el tipo interno real
        (ancho de entero, union, puntero tipado...), la salida siempre
        se reduce a int/float/string/bool/array/dict/tupla.
        """
        if isinstance(type_spec, Callback):
            if not c_value:
                return None  # puntero a función NULL
            return NativeCallback(c_value, type_spec.ret_type, type_spec.arg_types)

        if isinstance(type_spec, Ptr):
            if not c_value:
                return None  # puntero NULL
            try:
                pointee = c_value.contents
            except ValueError:
                return None
            return self._ctype_to_pyval(pointee, type_spec.base)

        if isinstance(type_spec, (tuple, list)):
            base, length = type_spec
            return [self._ctype_to_pyval(c_value[i], base) for i in range(int(length))]

        if isinstance(type_spec, str):
            info = self._structs.get(type_spec)
            if info is None:
                raise LinkerError(f"Struct/Union '{type_spec}' no definido.")
            out = {}
            values = []
            for fname, ftype, flen, fbits in info["fields"]:
                raw = getattr(c_value, fname)
                val = self._ctype_to_pyval(raw, (ftype, flen) if flen else ftype)
                out[fname] = val
                values.append(val)
            # as_tuple: se entrega como tupla posicional en vez de dict —
            # ambos son tipos estándar de Tesseract, solo cambia cuál.
            return tuple(values) if info.get("as_tuple") else out

        # escalar: puede llegar ya "desenvuelto" (acceso a campo de struct,
        # que ctypes auto-desenvuelve a valor Python plano) o como
        # instancia ctypes cruda (ej. resultado de TIPO.in_dll(...), que
        # NUNCA se autodesenvuelve solo). Cubre ambos casos.
        raw = c_value.value if hasattr(c_value, 'value') else c_value
        return convert_out(raw, type_spec)

    def _auto_build(self, value):
        """
        MEJOR ESFUERZO, sin declaración previa: infiere sobre la marcha la
        forma ctypes de un dict/lista/tupla a partir de los propios valores
        Python. Útil para 'dep.fn("foo", [1,2,3,4])' o
        'dep.fn("foo", {"vl1": 2})' cuando no llamaste defineStruct() antes.
        Para arreglos vacíos, o cuando el layout exacto importa (structs
        con huecos/padding específicos, tipos exactos por campo, uniones,
        bitfields, punteros tipados), usa defineStruct()/defineUnion() en
        vez de confiar en la inferencia.
        Devuelve (ctype, valor_listo_para_pasar_a_ctypes).
        """
        if isinstance(value, dict):
            parts = [(k, self._auto_build(v)) for k, v in value.items()]
            cls = type("_TSS_Anon", (ctypes.Structure,),
                       {"_fields_": [(k, ct) for k, (ct, _) in parts]})
            inst = cls()
            for k, (_, v) in parts:
                setattr(inst, k, v)
            return cls, inst

        if isinstance(value, (list, tuple)):
            if not value:
                raise LinkerError(
                    "No se puede inferir el tipo de un arreglo/tupla vacío "
                    "sin declararlo antes con defineStruct().")
            parts = [self._auto_build(v) for v in value]
            elem_ct = parts[0][0]
            arr_cls = elem_ct * len(parts)
            inst = arr_cls(*[v for _, v in parts])
            return arr_cls, inst

        if isinstance(value, bool):  return ctypes.c_bool, value
        if isinstance(value, int):
            tc = _infer_type(value)  # respeta _ffi_kind (._int8.._uint64) si lo trae
            return _CTYPE_MAP.get(tc, ctypes.c_int64), int(value)
        if isinstance(value, float):
            tc = _infer_type(value)  # respeta _ffi_kind (._float32/._longdouble) si lo trae
            return _CTYPE_MAP.get(tc, ctypes.c_double), float(value)
        if isinstance(value, str):   return ctypes.c_char_p, value.encode('utf-8')
        if value is None:            return ctypes.c_void_p, None
        return ctypes.c_void_p, value

    def _auto_read(self, inst):
        """
        Inverso de _auto_build: lee de vuelta una instancia ctypes armada
        SIN declaración previa (via _auto_build) a su valor Python otra
        vez — dict para lo que fue un dict, lista para lo que fue una
        lista/tupla, escalar para el resto. Se usa para leer un argumento
        marcado con '.out' cuando no hay defineStruct() de por medio.
        """
        if isinstance(inst, ctypes.Structure):
            return {f[0]: self._auto_read(getattr(inst, f[0])) for f in inst._fields_}
        if isinstance(inst, ctypes.Array):
            return [self._auto_read(inst[i]) for i in range(len(inst))]
        if hasattr(inst, 'value'):
            v = inst.value
            return v.decode('utf-8', errors='replace') if isinstance(v, bytes) else v
        return inst

    def _build_native_callback(self, ref, explicit_sig=None) -> Any:
        """
        Convierte una referencia a función de Tesseract (ver
        _is_function_ref / _FunctionPointerRef en interpre.py) en un
        callback REAL de libffi: un ctypes.CFUNCTYPE cuyo puntero el
        binario puede invocar de verdad (ej. como comparador de qsort,
        manejador de eventos, etc.) — al llamarlo, el trampolín de abajo
        ejecuta el cuerpo de la función Tesseract (via ref.invoke) y
        traduce el resultado de vuelta al ABI de C.

        explicit_sig: (ret_type, arg_types) — cuando el LLAMADOR ya sabe
        la firma exacta esperada (ej. un campo de struct o un argumento
        declarado como Callback(ret, args) en define()/defineStruct()),
        esa firma GANA sobre cualquier otra cosa: es la fuente de verdad
        más autoritativa (el propio sitio declarado), más que lo que la
        referencia crea que es. Sin esto, un campo de struct declarado
        Callback(INT32, [INT32]) podía terminar con un callback real de
        ancho distinto (ej. INT64, el default de "int" en Tesseract) y
        ctypes lo rechaza de plano por incompatibilidad de tipos —
        confirmado con una prueba real.

        Si no se da explicit_sig, se usa el criterio de siempre:
        'ref._ffi_kind' decide el ancho —
          - 'pointer' o 'function_pointer' (el caso base, sin marcar con
            ningún ancho explícito): se usa el tipo YA DECLARADO en
            Tesseract (ref.return_type, ej. "int function fn()").
          - cualquier otro kind (._int32, ._float32, ._bool, ._void...):
            ese ancho GANA sobre lo declarado — útil cuando el retorno
            declarado es 'dynamic'/genérico y hace falta precisar el
            ABI exacto del callback.

        Parámetros: se toman de ref.param_types (los tipos YA
        DECLARADOS de cada parámetro), salvo que linker.callbackSignature()
        haya puesto un override, o que explicit_sig lo diga todo.

        El objeto CFUNCTYPE resultante se guarda en self._callbacks para
        que no lo recolecte el garbage collector mientras el binario
        pueda seguir invocándolo — un callback recolectado deja al
        binario con un puntero colgante.
        """
        if explicit_sig is not None:
            ret_tc, arg_tcs = explicit_sig
        else:
            sig_override = getattr(ref, 'callback_signature', None) or {}

            if sig_override.get('return') is not None:
                # linker.callbackSignature(ref, return_type=...) manda sobre
                # cualquier otra cosa — es la forma más explícita de decirlo.
                ret_tc = sig_override['return']
            elif ref._ffi_kind in ('pointer', 'function_pointer'):
                ret_tc = _TESS_TYPE_TO_LINKER.get(ref.return_type, LINKER_INT)
            else:
                ret_tc = _FFI_KIND_TO_LINKER.get(ref._ffi_kind, LINKER_INT)

            if sig_override.get('params') is not None:
                # linker.callbackSignature(ref, param_types=[...]) — el ancho
                # EXACTO de cada parámetro del callback, en orden. Necesario
                # cuando el C real espera algo que no calza con los tipos
                # declarados en Tesseract (ej. 'float' de precisión simple en
                # un parámetro — en Tesseract solo existe 'float' = double).
                arg_tcs = list(sig_override['params'])
            else:
                arg_tcs = [_TESS_TYPE_TO_LINKER.get(t, LINKER_INT) for t in ref.param_types.values()]

        ret_ct = None if ret_tc == LINKER_VOID else _CTYPE_MAP.get(ret_tc, ctypes.c_int64)
        arg_cts = [_CTYPE_MAP.get(tc, ctypes.c_int64) for tc in arg_tcs]

        CFUNC = ctypes.CFUNCTYPE(ret_ct, *arg_cts)

        def _trampoline(*native_args):
            # Traducir cada argumento nativo de vuelta a un valor Python
            # simple ANTES de invocar la función Tesseract (misma
            # simplificación de siempre: todo llega como int/float/str/bool).
            py_args = [convert_out(a, tc) for a, tc in zip(native_args, arg_tcs)]
            result = ref.invoke(*py_args)
            if ret_ct is None:
                return None
            if ret_tc == LINKER_STRING:
                return result.encode('utf-8') if isinstance(result, str) else (result or b'')
            if ret_tc == LINKER_BOOL:
                return bool(result)
            if ret_tc in _INT_TYPES:
                return int(result) if result is not None else 0
            if ret_tc in _FLOAT_TYPES:
                return float(result) if result is not None else 0.0
            return result

        callback_fn = CFUNC(_trampoline)
        self._callbacks.append(callback_fn)  # evita que el GC lo recolecte
        return callback_fn

    def define(self, func_name: str, ret_type, arg_types: list, variadic: bool = False,
               calling_convention: Optional[str] = None, thiscall: bool = False):
        """
        ret_type / cada entrada de arg_types puede ser:
          - int: tipo primitivo (LINKER_INT, LINKER_FLOAT, cualquier
            ancho INT8..UINT64/FLOAT32/LONGDOUBLE, ...)
          - str: nombre de un struct/union ya definido con
            define_struct()/define_union()
          - (tipo, longitud): arreglo de 'longitud' elementos de 'tipo'
          - Ptr(tipo): puntero tipado (solo válido como argumento o como
            ret_type, nunca dentro de un struct via este parámetro — para
            eso se declara directo en define_struct)
          - Out(tipo, size=None): SOLO válido dentro de arg_types — marca
            un parámetro de salida / paso por referencia.
          - None: "inferir este argumento en cada llamada", respetando su
            marca _ffi_kind si el valor la trae (ej. x._int32, y.pointer
            — ver el bloque de atributos FFI en interpre.py). Útil para
            declarar SOLO el tipo de retorno (obligatorio: el ABI de C
            exige conocerlo ANTES de llamar — un int y un float vuelven
            en registros distintos de la CPU, así que esto no se puede
            inferir después de la llamada) sin tener que fijar a mano
            cada argumento, ej.: define("suma", LINKER_FLOAT32, [None, None]).
        variadic: si True, se permite pasar más argumentos en call() que
          los declarados aquí; los extra se infieren uno por uno en cada
          llamada (necesario porque libffi debe preparar el cif de una
          variadica según los tipos reales de esa llamada en particular,
          no puede fijarse una sola vez).
        """
        if calling_convention not in (None, "cdecl", "stdcall"):
            raise LinkerError(
                f"Convencion de llamada no soportada: '{calling_convention}'. "
                f"Solo 'cdecl', 'stdcall' o None (usar la general de la biblioteca)."
            )
        self._sigs[func_name] = _Signature(
            ret_type, list(arg_types), variadic,
            calling_convention=calling_convention, thiscall=thiscall)

    def _resolve_symbol_default(self, func_name: str):
        """
        Busca el símbolo con la convención general de la biblioteca
        (self._lib), y si no aparece ahí, en cada biblioteca extra
        cargada con loadDir(), en el orden en que se cargaron.
        """
        for handle in [self._lib] + [h for _, h in self._extra_libs]:
            try:
                return getattr(handle, func_name)
            except AttributeError:
                continue
        raise LinkerError(
            f"Simbolo '{func_name}' no encontrado en '{self._path.name}' "
            f"ni en las {len(self._extra_libs)} bibliotecas cargadas con loadDir().\n"
            f"  Asegurate de exportarlo con extern \"C\" en C++."
        )

    def _resolve_symbol_address(self, func_name: str) -> int:
        """
        Dirección cruda del símbolo, agnóstica de convención de llamada
        (getattr sobre un CDLL/WinDLL ya resuelve el símbolo — la
        convención solo importa al momento de INVOCARLO, no al buscar
        su dirección). Recorre self._lib y luego self._extra_libs.
        """
        for handle in [self._lib] + [h for _, h in self._extra_libs]:
            try:
                return ctypes.cast(getattr(handle, func_name), ctypes.c_void_p).value
            except AttributeError:
                continue
        raise LinkerError(
            f"Simbolo '{func_name}' no encontrado en '{self._path.name}' "
            f"ni en las {len(self._extra_libs)} bibliotecas cargadas con loadDir()."
        )

    def load_dir(self, path, subdirs: bool = False) -> dict:
        """
        Carga TODAS las bibliotecas precompiladas (.so/.dll/.dylib)
        encontradas en 'path'. subdirs=False (por defecto) solo mira el
        nivel superior de 'path'; subdirs=True recorre también las
        subcarpetas. No reemplaza la biblioteca principal (self._lib):
        las nuevas quedan disponibles como fuente adicional de símbolos
        para define()/fn()/vr(), en el orden en que se cargaron.
        Devuelve {"loaded": [...rutas...], "failed": [{"path":.., "error":..}]}.
        """
        base = Path(path)
        if not base.is_dir():
            raise LinkerError(f"'{path}' no es un directorio valido.")

        candidatos = base.rglob('*') if subdirs else base.iterdir()
        cargados, fallidos = [], []

        for p in candidatos:
            if not p.is_file():
                continue
            if p.suffix.lower() not in ('.so', '.dll', '.dylib'):
                continue

            real = str(p.resolve())
            if real == str(self._path.resolve()):
                continue
            if any(real == r for r, _ in self._extra_libs):
                continue

            try:
                if self._calling_convention == "stdcall" and sys.platform == "win32":
                    handle = ctypes.WinDLL(real, use_last_error=True)
                else:
                    mode = getattr(ctypes, "RTLD_GLOBAL", 0)
                    handle = ctypes.CDLL(real, mode=mode, use_errno=True)
                self._extra_libs.append((real, handle))
                cargados.append(real)
            except OSError as e:
                fallidos.append({"path": real, "error": str(e)})

        return {"loaded": cargados, "failed": fallidos}

    def _build_thiscall_trampoline(self, target_addr: int) -> int:
        """
        Trampolin de 10 bytes: adapta una llamada estilo cdecl
        (this, arg2, arg3, ...) a una llamada real thiscall (this en
        ECX, el resto en pila) hacia target_addr. No usa ningún
        compilador externo — son bytes de máquina x86 escritos a mano y
        volcados a una página de memoria marcada ejecutable con las
        funciones de Windows para memoria. Solo aplica en Windows de 32
        bits, único caso donde 'thiscall' es una convención distinta de
        cdecl/stdcall.
        """
        if sys.platform != "win32" or ctypes.sizeof(ctypes.c_void_p) != 4:
            raise LinkerError(
                "thiscall solo esta soportado en Windows de 32 bits.")

        codigo = (bytes([0x58, 0x59, 0x50, 0xB8])
                  + struct.pack('<I', target_addr)
                  + bytes([0xFF, 0xE0]))

        kernel32 = ctypes.windll.kernel32
        direccion = kernel32.VirtualAlloc(
            None, len(codigo), 0x1000 | 0x2000, 0x40)
        if not direccion:
            raise LinkerError(
                "No se pudo reservar memoria ejecutable para el trampolin thiscall.")

        ctypes.memmove(direccion, codigo, len(codigo))
        self._keepalive.append(codigo)  # referencia viva, aunque el buffer real ya está copiado
        return direccion

    def call(self, func_name: str, args: list) -> Any:
        fn = self._resolve_symbol_default(func_name)

        sig = self._sigs.get(func_name)
        out_storage = []   # (posicion, storage_ctypes, base_type_spec) — solo con sig

        if sig:
            fixed_types = sig.arg_types
            n_fixed = len(fixed_types)
            argtypes = []
            c_args   = []

            for i, t in enumerate(fixed_types):
                a = args[i] if i < len(args) else None

                if _is_function_ref(a):
                    # Referencia a función de Tesseract (myFunc(...).algo):
                    # si 't' es un Callback(...) declarado explícitamente
                    # (ej. define("fn", ret, [linker.callback(...)])), esa
                    # firma GANA sobre lo que la función Tesseract cree que
                    # es — es la fuente de verdad más autoritativa.
                    if isinstance(t, Callback):
                        callback_fn = self._build_native_callback(
                            a, explicit_sig=(t.ret_type, t.arg_types))
                    else:
                        callback_fn = self._build_native_callback(a)
                    argtypes.append(type(callback_fn))
                    c_args.append(callback_fn)
                    continue

                if t is None:
                    # None = "inferir este argumento en esta llamada en
                    # particular", respetando su marca _ffi_kind si el
                    # valor la trae (ej. x._int32) — util para declarar
                    # SOLO el tipo de retorno (obligatorio: el ABI de C
                    # exige saberlo ANTES de llamar, un int y un float
                    # vuelven en registros distintos de la CPU) sin tener
                    # que fijar a mano cada tipo de argumento.
                    t = _infer_arg_spec(a)

                if isinstance(t, Aligned):
                    base_ct = self._resolve_ctype(t.base)
                    size = ctypes.sizeof(base_ct)
                    # Reserva un bloque de sobra y recorta a mano hasta la
                    # primera dirección múltiplo de t.align dentro de él.
                    raw = ctypes.create_string_buffer(size + t.align)
                    addr = ctypes.addressof(raw)
                    aligned_addr = (addr + t.align - 1) & ~(t.align - 1)
                    inst = base_ct.from_address(aligned_addr)
                    fuente = self._pyval_to_cinstance(a, t.base)
                    ctypes.memmove(ctypes.addressof(inst), ctypes.addressof(fuente), size)
                    # 'raw' tiene que seguir vivo mientras dure la llamada
                    # (y en rigor mientras el binario pueda seguir leyendo
                    # esa dirección después) — se cuelga del bridge, no de
                    # esta función, para no perderlo al recolector.
                    self._keepalive.append(raw)
                    argtypes.append(ctypes.c_void_p)
                    c_args.append(aligned_addr)
                elif isinstance(t, Out):
                    base = t.base
                    pass_direct = False
                    if base == LINKER_STRING:
                        size = t.size or 256
                        initial = a.encode('utf-8') if isinstance(a, str) else b''
                        storage = ctypes.create_string_buffer(initial, size)
                        argtypes.append(ctypes.c_char_p)
                        pass_direct = True
                    elif base == LINKER_WSTRING:
                        size = t.size or 256
                        storage = ctypes.create_unicode_buffer(a if isinstance(a, str) else '', size)
                        argtypes.append(ctypes.c_wchar_p)
                        pass_direct = True
                    elif isinstance(base, str):
                        storage = self._pyval_to_cinstance(a if a is not None else {}, base)
                        argtypes.append(ctypes.POINTER(self._resolve_ctype(base)))
                    elif isinstance(base, (tuple, list)):
                        storage = self._pyval_to_cinstance(a if a is not None else [], base)
                        argtypes.append(ctypes.POINTER(self._resolve_ctype(base)))
                    else:
                        base_ct = self._resolve_ctype(base)
                        storage = base_ct(self._scalar_in(a, base) if a is not None else 0)
                        argtypes.append(ctypes.POINTER(base_ct))

                    out_storage.append((i, storage, base))
                    c_args.append(storage if pass_direct else ctypes.pointer(storage))
                else:
                    argtypes.append(self._resolve_ctype(t))
                    c_args.append(self._pyval_to_cinstance(a, t))

            # Variadicos: los argumentos extra se infieren valor por valor,
            # y se anexan tanto a argtypes como a c_args de ESTA llamada en
            # particular (no se puede fijar de antemano para variadicas).
            if sig.variadic and len(args) > n_fixed:
                for a in args[n_fixed:]:
                    if isinstance(a, (list, tuple, dict)):
                        ct, v = self._auto_build(a)
                    elif a is None:
                        # None en la parte variadica = puntero nulo explicito
                        # (ej. el ultimo argumento de IupVbox(...)). NoneType
                        # no es un ctype valido para argtypes; c_void_p si.
                        ct, v = ctypes.c_void_p, None
                    else:
                        tc = _infer_type(a)
                        v  = convert_in_ctypes(a, tc)
                        if tc == LINKER_STRING:
                            # convert_in_ctypes devuelve bytes CRUDOS para
                            # STRING (no una instancia de ctypes) — type(v)
                            # daria la clase 'bytes' de Python, que no sirve
                            # como ctype en argtypes (no tiene from_param).
                            ct = ctypes.c_char_p
                        elif tc == LINKER_WSTRING:
                            # Mismo caso: WSTRING devuelve un str crudo.
                            ct = ctypes.c_wchar_p
                        else:
                            ct = type(v)
                            # Reglas de promoción de argumentos variádicos de C:
                            # todo float de precisión simple se promueve a
                            # double, y todo entero más chico que 'int' se
                            # promueve a int/unsigned int. Sin esto, un valor
                            # marcado explícitamente con ancho reducido
                            # (ej. x._int8, x._float32) pasado en la parte
                            # variádica viajaría con un ancho menor al que el
                            # ABI de C exige ahí, desalineando la pila del lado
                            # del binario.
                            if ct is ctypes.c_float:
                                v, ct = ctypes.c_double(v.value), ctypes.c_double
                            elif ct in (ctypes.c_int8, ctypes.c_int16):
                                v, ct = ctypes.c_int32(v.value), ctypes.c_int32
                            elif ct in (ctypes.c_uint8, ctypes.c_uint16):
                                v, ct = ctypes.c_uint32(v.value), ctypes.c_uint32
                    argtypes.append(ct)
                    c_args.append(v)

            restype = self._resolve_ctype(sig.ret_type) if sig.ret_type != LINKER_VOID else None
            if sig.thiscall:
                direccion_real = self._resolve_symbol_address(func_name)
                direccion_trampolin = self._build_thiscall_trampoline(direccion_real)
                fn = ctypes.CFUNCTYPE(restype, *argtypes)(direccion_trampolin)
            elif sig.calling_convention and sig.calling_convention != self._calling_convention:
                # Esta función puntual pide una convención distinta a la
                # general de la biblioteca: se resuelve la dirección cruda
                # del símbolo (agnóstica a la convención) y se construye el
                # tipo llamable correcto solo para esta llamada, sin afectar
                # a ninguna otra función definida sobre la misma biblioteca.
                direccion_real = self._resolve_symbol_address(func_name)
                if sig.calling_convention == "stdcall":
                    fn = ctypes.WINFUNCTYPE(restype, *argtypes)(direccion_real)
                else:
                    fn = ctypes.CFUNCTYPE(restype, *argtypes)(direccion_real)
            else:
                fn.restype  = restype
                fn.argtypes = argtypes

        elif any(isinstance(a, (list, tuple, dict)) or _ffi_kind_of(a) is not None for a in args):
            # Sin define() previo. Si algun argumento es agregado
            # (arreglo/tupla/dict) se infiere su forma sobre la marcha; si
            # trae una marca '.pointer' se pasa por DIRECCION sin leer nada
            # de vuelta; si trae '.out' se pasa por DIRECCION Y ADEMAS se
            # lee lo que el binario haya escrito ahi despues de la llamada
            # (se combina con el retorno como tupla, igual que Out() en el
            # camino CON firma — reutiliza el mismo 'out_storage' que ya se
            # lee mas abajo, tenga o no firma declarada esta llamada).
            c_argtypes, c_args = [], []
            for a in args:
                if _is_function_ref(a):
                    callback_fn = self._build_native_callback(a)
                    c_argtypes.append(type(callback_fn))
                    c_args.append(callback_fn)
                    continue
                kind = _ffi_kind_of(a)
                if isinstance(a, (list, tuple, dict)):
                    ct, v = self._auto_build(a)
                    if kind in ('pointer', 'out'):
                        c_argtypes.append(ctypes.POINTER(ct))
                        c_args.append(ctypes.pointer(v))
                        if kind == 'out':
                            out_storage.append((len(c_args) - 1, v, '__auto__'))
                    else:
                        c_argtypes.append(ct)
                        c_args.append(v)
                elif kind in ('pointer', 'out'):
                    # Escalar marcado con .pointer/.out: se envuelve en su
                    # ctype real (o un buffer, si es string) y se pasa la
                    # DIRECCION de esa instancia.
                    if isinstance(a, str) and not isinstance(a, bool):
                        size = 256  # tamaño por defecto: un atributo no lleva
                                    # parametro de tamaño; para uno exacto
                                    # segui usando linker.out(tipo, tamaño)
                        initial = a.encode('utf-8')
                        storage = ctypes.create_string_buffer(initial, size)
                        c_argtypes.append(ctypes.c_char_p)
                        c_args.append(storage)
                        if kind == 'out':
                            out_storage.append((len(c_args) - 1, storage, LINKER_STRING))
                    else:
                        base_tc = LINKER_INT if isinstance(a, int) and not isinstance(a, bool) else \
                                  LINKER_FLOAT if isinstance(a, float) else LINKER_INT
                        base_ct = _CTYPE_MAP[base_tc]
                        inst = base_ct(self._scalar_in(a, base_tc))
                        c_argtypes.append(ctypes.POINTER(base_ct))
                        c_args.append(ctypes.pointer(inst))
                        if kind == 'out':
                            out_storage.append((len(c_args) - 1, inst, base_tc))
                else:
                    tc = _infer_type(a)
                    v  = convert_in_ctypes(a, tc)
                    if tc == LINKER_STRING:
                        c_argtypes.append(ctypes.c_char_p)
                    elif tc == LINKER_WSTRING:
                        c_argtypes.append(ctypes.c_wchar_p)
                    else:
                        c_argtypes.append(type(v))
                    c_args.append(v)
            fn.argtypes = c_argtypes
        else:
            # Todos los argumentos son escalares simples (sin agregados ni
            # marcas '.pointer') — convert_in_ctypes ya respeta '_ffi_kind'
            # para anchos numericos (._int32, ._float32, etc.) via
            # _infer_type, asi que ni siquiera hace falta armar argtypes
            # explicitos aqui: ctypes los infiere bien de cada valor.
            c_args = [convert_in_ctypes(a) for a in args]

        try:
            result = fn(*c_args)
        except ctypes.ArgumentError as e:
            raise LinkerError(f"Error de tipos en '{func_name}': {e}")

        # ── Valor de retorno normal ──────────────────────────────────────
        if sig and sig.ret_type == LINKER_VOID:
            ret_val = None
        elif sig and isinstance(sig.ret_type, (Ptr, Callback, str, tuple, list)):
            ret_val = self._ctype_to_pyval(result, sig.ret_type)
        else:
            ret_tc = sig.ret_type if sig else _infer_type(result)
            ret_val = convert_out(result, ret_tc)

        # ── Parámetros Out(...) / .out, en el orden en que se pasaron ───
        out_vals = []
        for i, storage, base in out_storage:
            if base == '__auto__':
                out_vals.append(self._auto_read(storage))
            elif base == LINKER_STRING:
                raw = storage.value
                out_vals.append(raw.decode('utf-8', errors='replace') if isinstance(raw, bytes) else raw)
            elif base == LINKER_WSTRING:
                out_vals.append(storage.value)
            elif isinstance(base, (str, tuple, list)):
                out_vals.append(self._ctype_to_pyval(storage, base))
            else:
                out_vals.append(convert_out(storage.value, base))

        if out_vals:
            parts = ([] if (sig and sig.ret_type == LINKER_VOID) else [ret_val]) + out_vals
            return parts[0] if len(parts) == 1 else tuple(parts)

        return ret_val

    def define_var(self, var_name: str, type_code, length: int = None):
        """
        Declara el tipo de una variable global exportada por el precompilado.
        type_code puede ser un primitivo (LINKER_INT, cualquier ancho...),
        el nombre de un struct/union ya definido, o Ptr(tipo). 'length' la
        convierte en arreglo.

        Si nunca se llama define_var() para una variable, get_var/set_var
        asumen LINKER_INT (comportamiento previo, retrocompatible).
        """
        tc = type_code if isinstance(type_code, (str, Ptr)) else int(type_code)
        self._var_sigs[var_name] = (tc, int(length) if length else None)

    def _var_in_dll(self, base_ctype, var_name: str):
        """
        TIPO.in_dll(handle, nombre) sobre self._lib, y si no aparece ahí,
        sobre cada biblioteca extra cargada con loadDir(), en orden.
        """
        for handle in [self._lib] + [h for _, h in self._extra_libs]:
            try:
                return base_ctype.in_dll(handle, var_name)
            except (AttributeError, ValueError):
                continue
        raise LinkerError(
            f"Variable '{var_name}' no encontrada en '{self._path.name}' "
            f"ni en las {len(self._extra_libs)} bibliotecas cargadas con loadDir()."
        )

    def get_var(self, var_name: str, type_code=None, length: int = None) -> Any:
        # NUNCA usar getattr(self._lib, ...) para variables: ctypes.CDLL
        # trata cualquier símbolo obtenido así como puntero a función
        # (_FuncPtr), tenga o no sentido para datos. Para leer una
        # variable real hay que pedir el tipo explícito con
        # TIPO.in_dll(lib, nombre).
        tc, ln = self._var_sigs.get(var_name, (LINKER_INT, None))
        if type_code is not None:
            tc = type_code if isinstance(type_code, (str, Ptr)) else int(type_code)
        if length is not None:
            ln = int(length)

        type_spec = (tc, ln) if ln else tc
        base_ctype = self._resolve_ctype(type_spec)

        c_value = self._var_in_dll(base_ctype, var_name)
        return self._ctype_to_pyval(c_value, type_spec)

    def set_var(self, var_name: str, value: Any, type_code=None, length: int = None):
        tc, ln = self._var_sigs.get(var_name, (LINKER_INT, None))
        if type_code is not None:
            tc = type_code if isinstance(type_code, (str, Ptr)) else int(type_code)
        if length is not None:
            ln = int(length)

        type_spec = (tc, ln) if ln else tc
        base_ctype = self._resolve_ctype(type_spec)

        c_value = self._var_in_dll(base_ctype, var_name)
        new_inst = self._pyval_to_cinstance(value, type_spec)
        ctypes.memmove(ctypes.byref(c_value), ctypes.byref(new_inst), ctypes.sizeof(base_ctype))

    def last_error(self) -> dict:
        """
        Estado de error del sistema tras la última llamada nativa.
        POSIX: errno + strerror(). Windows: GetLastError + su mensaje.
        Se simplifica siempre a dict {"errno": int, "message": str} para
        respetar los tipos estándar de Tesseract (dict).
        Requiere que la librería se haya cargado con use_errno/
        use_last_error — cosa que ahora se hace siempre por defecto.
        """
        if sys.platform == 'win32':
            code = ctypes.get_last_error()
            try:
                message = ctypes.FormatError(code)
            except Exception:
                message = ''
            return {"errno": int(code), "message": str(message)}
        code = ctypes.get_errno()
        try:
            message = os.strerror(code) if code else ''
        except Exception:
            message = ''
        return {"errno": int(code), "message": str(message)}

    def _free_handle(self, handle):
        try:
            raw = handle._handle
            if sys.platform == 'win32':
                ctypes.windll.kernel32.FreeLibrary(raw)
            else:
                try:
                    libdl = ctypes.CDLL("libdl.so.2")
                except OSError:
                    libdl = ctypes.CDLL(None)
                libdl.dlclose(raw)
        except Exception:
            pass

    def unload(self):
        if self._lib:
            self._free_handle(self._lib)
            self._lib = None
        # Bibliotecas adicionales cargadas con loadDir(): sin esto quedaban
        # cargadas en memoria hasta que terminara el proceso, aunque se
        # llamara unload() sobre el LinkerObject principal.
        for _, handle in self._extra_libs:
            self._free_handle(handle)
        self._extra_libs = []


# ════════════════════════════════════════════════════════════════════════
#  RUTA B — C fuente/objeto via libtcc EMBEBIDO (sin pip, sin gcc/clang
#  ni tcc instalados en la maquina del usuario)
# ════════════════════════════════════════════════════════════════════════
#
# DISEÑO: en vez de mantener un motor C aparte con su propia logica de
# tipos/structs/punteros (como hacia la version anterior via pytcc), se
# compila el .c/.o de entrada con la API nativa de libtcc (via ctypes
# directo, SIN ningun wrapper de Python de terceros) a un .so/.dll/.dylib
# REAL en un archivo temporal, y ESE archivo se le entrega a _FFIBridge —
# la misma ruta A que ya carga precompilados. A partir de ahi, codigo
# fuente C tiene automaticamente TODO lo que ya tiene un .so precompilado:
# define(), define_struct()/define_union(), Ptr/Out/Callback, variadicas,
# lastError(), etc. — sin duplicar ni un solo tipo de conversion.
#
# libtcc.dll / libtcc.so / libtcc.dylib se bundlea junto con el resto de
# dependencias nativas del proyecto en deps/tcc/ (una compilacion por
# sistema operativo, hecha una sola vez en desarrollo/CI — NUNCA en la
# maquina del usuario final). Junto al binario tienen que vivir tambien
# los archivos de soporte propios de TCC (libtcc1.a y los headers
# estandar que trae la distribucion oficial), porque libtcc los necesita
# en tiempo de compilacion para poder generar código válido — no alcanza
# con la biblioteca dinámica sola.
#
# NOTA (Windows): a diferencia de otros compiladores, ESTE bridge activa
# siempre la opcion '-rdynamic' de TCC antes de compilar (ver
# _CEngineBridge), que en su escritor de PE hace que se exporten TODOS
# los simbolos globales automaticamente — por eso el codigo fuente del
# usuario NO necesita marcar nada con __attribute__((dllexport)) ni
# escribir ningun #ifdef _WIN32: un .c en C puro y corriente ya expone
# sus funciones/variables globales igual en Windows, Linux y macOS.

_TCC_OUTPUT_MEMORY     = 1
_TCC_OUTPUT_EXE        = 2
_TCC_OUTPUT_DLL        = 4
_TCC_OUTPUT_OBJ        = 3
_TCC_OUTPUT_PREPROCESS = 5


def _tcc_dir() -> Path:
    """Carpeta raiz donde vive todo lo de TCC bundleado: deps/tcc/."""
    return _DEPS_DIR / "tcc"


def _tcc_platform_dir() -> Path:
    """Subcarpeta por sistema operativo dentro de deps/tcc/ — ahi viven
    juntos el binario (libtcc.dll/.so/.dylib), las variantes de runtime
    (libtcc1-64.a / libtcc1-32.a) y, opcionalmente, los headers estandar
    de la distribucion de TCC (include/, include/winapi/ en Windows)."""
    if sys.platform == 'win32':
        return _tcc_dir() / "win32"
    if sys.platform == 'darwin':
        return _tcc_dir() / "mac"
    return _tcc_dir() / "linux"


def _process_bits() -> int:
    """64 o 32 segun el proceso de Python ACTUAL (no el sistema operativo
    en si) — determina que variante de libtcc.dll/libtcc1 hace falta,
    porque un proceso de 64 bits no puede cargar una DLL de 32 y
    viceversa."""
    return 64 if ctypes.sizeof(ctypes.c_void_p) == 8 else 32


def _find_libtcc() -> Path:
    pdir = _tcc_platform_dir()
    bits = _process_bits()
    lib_name = {"win32": "libtcc.dll", "darwin": "libtcc.dylib"}.get(sys.platform, "libtcc.so")
    # Se admiten dos layouts: separado por bitness en subcarpeta
    # (win32/64/libtcc.dll, win32/32/libtcc.dll) para cuando se
    # bundleen ambas arquitecturas, o un unico binario suelto
    # directamente en win32/ (el caso mas comun: un solo libtcc.dll
    # que coincide con el Python que se este usando).
    candidates = [
        pdir / str(bits) / lib_name,
        pdir / lib_name,
        _tcc_dir() / lib_name,
    ]
    for c in candidates:
        if c.exists():
            return c
    raise LinkerError(
        f"No se encontro libtcc para esta plataforma ({sys.platform}, "
        f"{bits} bits) en '{pdir}'.\n"
        f"  Se espera '{lib_name}' ahi (o en una subcarpeta '{bits}/'), "
        f"bundleado junto al resto de deps/."
    )


def _find_libtcc1(pdir: Path) -> Optional[Path]:
    """
    libtcc1 es la libreria de RUNTIME de TCC (rutinas de soporte que el
    codigo compilado puede necesitar en tiempo de ejecucion — division/
    conversion de enteros de 64 bits en plataformas que no las tienen
    como instruccion nativa, helpers de floats, etc.). La distribucion
    oficial de TCC para Windows la separa por arquitectura de SALIDA
    (libtcc1-64.a / libtcc1-32.a) en vez de un unico 'libtcc1.a' — por
    eso NO se usa tcc_set_lib_path() para que TCC la busque sola con su
    convencion de nombre interna (fallaria contra estos nombres), sino
    que se localiza aca explicitamente segun el bitness del proceso y
    se linkea a mano con tcc_add_file().
    No encontrarla no es necesariamente fatal: hay codigo C simple que
    no toca ninguna de esas rutinas y compila igual sin ella — por eso
    esta funcion devuelve None en vez de lanzar error, y quien la llama
    decide si continuar o no.
    """
    bits = _process_bits()
    lib_sub = pdir / "lib"
    candidates = [
        # Layout mas comun de la distribucion oficial: libtcc.dll suelto
        # en la carpeta de la plataforma (win32/), y libtcc1.a + las
        # librerias de import (kernel32.a, msvcrt.a, etc.) juntas dentro
        # de la subcarpeta win32/lib/.
        lib_sub / str(bits) / f"libtcc1-{bits}.a",
        lib_sub / f"libtcc1-{bits}.a",
        lib_sub / str(bits) / "libtcc1.a",
        lib_sub / "libtcc1.a",
        # Variante sin subcarpeta 'lib/' (por si se bundlea todo suelto
        # directamente en la carpeta de la plataforma).
        pdir / str(bits) / f"libtcc1-{bits}.a",
        pdir / f"libtcc1-{bits}.a",
        pdir / str(bits) / "libtcc1.a",
        pdir / "libtcc1.a",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def _find_tcc_include_dirs(pdir: Path) -> list:
    """
    Headers ESTANDAR propios de la distribucion de TCC (stdio.h,
    stdlib.h, string.h, math.h, stdint.h, y en Windows ademas
    windows.h/winapi) — sin estos, cualquier codigo C minimamente
    normal que haga #include <...> no compila, porque TCC no asume
    ningun compilador del sistema instalado del cual heredar headers.
    """
    dirs = []
    inc = pdir / "include"
    if inc.exists():
        dirs.append(inc)
        winapi = inc / "winapi"
        if sys.platform == "win32" and winapi.exists():
            dirs.append(winapi)
    return dirs


class _LibTCC:
    """
    Binding ctypes MINIMO contra la API nativa de libtcc.h — solo lo
    necesario para compilar codigo fuente C a un .so/.dll/.dylib real en
    disco. No depende de ningun paquete de pip para TCC: solo del propio
    binario de libtcc bundleado.
    """

    _instance: Optional["_LibTCC"] = None

    def __init__(self, lib_path: Path):
        self._lib_path = lib_path
        try:
            self._lib = ctypes.CDLL(str(lib_path))
        except OSError as e:
            raise LinkerError(f"No se pudo cargar libtcc ('{lib_path}'):\n  {e}")

        L = self._lib

        L.tcc_new.restype      = ctypes.c_void_p
        L.tcc_new.argtypes     = []

        L.tcc_delete.restype   = None
        L.tcc_delete.argtypes  = [ctypes.c_void_p]

        L.tcc_set_output_type.restype  = ctypes.c_int
        L.tcc_set_output_type.argtypes = [ctypes.c_void_p, ctypes.c_int]

        L.tcc_add_file.restype  = ctypes.c_int
        L.tcc_add_file.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        L.tcc_output_file.restype  = ctypes.c_int
        L.tcc_output_file.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        L.tcc_add_include_path.restype  = ctypes.c_int
        L.tcc_add_include_path.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        L.tcc_add_library_path.restype  = ctypes.c_int
        L.tcc_add_library_path.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        L.tcc_add_library.restype  = ctypes.c_int
        L.tcc_add_library.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        L.tcc_set_lib_path.restype  = None
        L.tcc_set_lib_path.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        # tcc_set_options(state, "-rdynamic") — ver nota junto a su uso
        # en _CEngineBridge: en la escritura de PE (tccpe.c) de TCC,
        # '-rdynamic' hace que se exporten TODOS los simbolos globales
        # automaticamente, sin requerir __attribute__((dllexport)) en el
        # codigo fuente del usuario.
        L.tcc_set_options.restype  = None
        L.tcc_set_options.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        # tcc_set_error_func(state, opaque, callback(opaque, msg)) —
        # unico modo de recuperar el TEXTO de los errores de compilacion;
        # sin esto, tcc_add_file/tcc_output_file solo devuelven -1 sin
        # ningun detalle de que salio mal.
        self._error_cb_t = ctypes.CFUNCTYPE(None, ctypes.c_void_p, ctypes.c_char_p)
        L.tcc_set_error_func.restype  = None
        L.tcc_set_error_func.argtypes = [ctypes.c_void_p, ctypes.c_void_p, self._error_cb_t]

    @classmethod
    def instance(cls) -> "_LibTCC":
        # Un solo binding cargado por proceso — libtcc.dll/.so se abre
        # una vez; cada compilacion crea y destruye su propio TCCState
        # (tcc_new/tcc_delete), que es liviano.
        if cls._instance is None:
            cls._instance = cls(_find_libtcc())
        return cls._instance

    @property
    def lib(self):
        return self._lib

    def make_error_collector(self):
        """Devuelve (lista_de_mensajes, callback_ctypes_vivo). El
        callback hay que mantenerlo referenciado mientras dure la
        compilacion (mismo motivo que _callbacks en _FFIBridge: si se
        recolecta como basura, TCC queda con un puntero colgante)."""
        errors: list = []

        def _on_error(_opaque, msg):
            errors.append((msg or b"").decode("utf-8", "replace"))

        cb = self._error_cb_t(_on_error)
        return errors, cb


class _CEngineBridge:
    """
    Ruta B para .c / .o: compila el codigo fuente con libtcc directo a un
    .so/.dll/.dylib REAL en un archivo temporal, y delega TODO lo demas
    (define, define_struct, define_union, Ptr/Out/Callback, variadicas,
    lastError, unload...) a un _FFIBridge normal sobre ese binario ya
    compilado — exactamente el mismo camino que un .so precompilado.
    """

    def __init__(self, path: Path, calling_convention: str = "cdecl",
                 global_symbols: bool = False):
        self._src_path = path
        self._tmp_dir: Optional[Path] = None

        ext = path.suffix.lower()
        if ext not in _C_SRC_EXTS:
            raise LinkerError(f"_CEngineBridge: extension no soportada '{ext}' (solo .c / .o).")

        tcc = _LibTCC.instance()
        L = tcc.lib

        state = L.tcc_new()
        if not state:
            raise LinkerError("libtcc: tcc_new() fallo al crear el estado de compilacion.")

        errors, error_cb = tcc.make_error_collector()
        L.tcc_set_error_func(state, None, error_cb)

        def _fail(msg: str):
            L.tcc_delete(state)
            detail = ("\n  " + "\n  ".join(errors)) if errors else ""
            raise LinkerError(f"{msg}{detail}")

        try:
            pdir = _tcc_platform_dir()

            # tcc_set_lib_path() se deja puesto igual, como red de
            # seguridad para cualquier busqueda interna de TCC que SI
            # respete su convencion de nombre por defecto — pero NO se
            # depende de el para libtcc1 (ver _find_libtcc1).
            L.tcc_set_lib_path(state, str(pdir).encode("utf-8"))

            if L.tcc_set_output_type(state, _TCC_OUTPUT_DLL) < 0:
                _fail(f"libtcc: no se pudo fijar el tipo de salida a DLL para '{path.name}'.")

            # '-rdynamic': exporta automaticamente TODOS los simbolos
            # globales del binario resultante, sin que el usuario tenga
            # que anotar cada funcion/variable con
            # __attribute__((dllexport)) (ni escribir ningun #ifdef
            # _WIN32 en su .c). En Windows esto es lo que de otra forma
            # haria falta a mano (tccpe.c: "si -rdynamic, se exportan
            # todos los simbolos no locales"); en Linux/macOS es un
            # no-op inofensivo, porque un .so ya exporta sus simbolos
            # globales por defecto. Se deja SIEMPRE activo, para las tres
            # plataformas por igual — asi el mismo .c compila y expone
            # sus funciones sin cambios sin importar en que sistema
            # operativo se genere el binario final.
            L.tcc_set_options(state, b"-rdynamic")

            # Headers ESTANDAR de la distribucion de TCC (stdio.h,
            # stdlib.h, string.h, math.h, stdint.h, winapi en Windows) —
            # sin esto, cualquier #include <...> normal no resuelve.
            for inc_dir in _find_tcc_include_dirs(pdir):
                L.tcc_add_include_path(state, str(inc_dir).encode("utf-8"))

            # El directorio del propio archivo fuente entra tambien como
            # include path, para que un #include "otroarchivo.h" relativo
            # al .c funcione igual que compilando con gcc/clang.
            L.tcc_add_include_path(state, str(path.parent).encode("utf-8"))

            # La subcarpeta lib/ de la plataforma entra como library path
            # del propio TCC — ahi viven tanto libtcc1.a como (en
            # Windows) las import libraries del sistema que la
            # distribucion de TCC trae consigo (kernel32.a, msvcrt.a,
            # etc.), necesarias para poder generar una DLL que llame a
            # funciones estandar (printf, malloc...).
            lib_sub = pdir / "lib"
            if lib_sub.exists():
                L.tcc_add_library_path(state, str(lib_sub).encode("utf-8"))

            # En Linux/macOS, ademas, funciones de math.h (sin, cos,
            # pow, sqrt...) viven en libm por separado de la libc base —
            # se intenta enlazar de entrada, best-effort: si el codigo
            # no la necesita o el sistema no la tiene separada, no pasa
            # nada.
            if sys.platform != "win32":
                L.tcc_add_library_path(state, str(pdir).encode("utf-8"))
                L.tcc_add_library(state, b"m")

            if L.tcc_add_file(state, str(path).encode("utf-8")) < 0:
                _fail(f"Error compilando '{path.name}' con TCC:")

            # libtcc1 (rutinas de runtime) se linkea DESPUES del archivo
            # fuente/objeto principal, que es el que puede necesitarlas —
            # y de forma explicita (no por la convencion de nombre interna
            # de TCC), porque la distribucion la trae como
            # libtcc1-64.a/libtcc1-32.a en vez de 'libtcc1.a'.
            libtcc1 = _find_libtcc1(pdir)
            if libtcc1 is not None:
                if L.tcc_add_file(state, str(libtcc1).encode("utf-8")) < 0:
                    _fail(f"Error enlazando '{libtcc1.name}' (runtime de TCC):")

            suffix = {"win32": ".dll", "darwin": ".dylib"}.get(sys.platform, ".so")
            tmp_dir = Path(tempfile.mkdtemp(prefix="tess_cengine_"))
            out_path = tmp_dir / (path.stem + suffix)

            if L.tcc_output_file(state, str(out_path).encode("utf-8")) < 0:
                shutil.rmtree(tmp_dir, ignore_errors=True)
                _fail(f"Error generando el binario de '{path.name}':")
        finally:
            L.tcc_delete(state)

        if not out_path.exists():
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise LinkerError(f"TCC no genero el archivo de salida esperado: {out_path}")

        # A partir de aca, TODO (define/define_struct/define_union/
        # Ptr/Out/Callback/lastError/unload/...) es el mismo camino que
        # un .so precompilado — se reusa _FFIBridge tal cual.
        self._impl = _FFIBridge(out_path, calling_convention, global_symbols)
        self._tmp_dir = tmp_dir

    def __getattr__(self, name):
        # Cualquier metodo no definido aca (define, define_struct,
        # define_union, define_var, get_var, set_var, call, last_error,
        # load_dir, ...) se delega directo al _FFIBridge real sobre el
        # binario ya compilado.
        return getattr(self._impl, name)

    def unload(self):
        try:
            self._impl.unload()
        finally:
            if self._tmp_dir is not None:
                shutil.rmtree(self._tmp_dir, ignore_errors=True)
                self._tmp_dir = None


# ════════════════════════════════════════════════════════════════════════
#  RUTA B (preparada) — Python fuente via importlib
# ════════════════════════════════════════════════════════════════════════

class _PyBridge:
    def __init__(self, path: Path):
        self._path = path
        self._sigs: dict = {}
        spec = importlib.util.spec_from_file_location("_tess_py_ext", str(path))
        if spec is None:
            raise LinkerError(f"No se pudo cargar el modulo Python: {path}")
        self._mod = importlib.util.module_from_spec(spec)
        script_dir = str(path.parent)
        if script_dir not in sys.path:
            sys.path.insert(0, script_dir)
        spec.loader.exec_module(self._mod)

    def define(self, func_name: str, ret_type: int, arg_types: list):
        self._sigs[func_name] = _Signature(int(ret_type), [int(t) for t in arg_types])

    def call(self, func_name: str, args: list) -> Any:
        fn = getattr(self._mod, func_name, None)
        if fn is None or not callable(fn):
            raise LinkerError(f"'{func_name}' no existe o no es callable en '{self._path.name}'")
        sig = self._sigs.get(func_name)
        py_args = [convert_in(a, t) for a, t in zip(args, sig.arg_types)] if sig else list(args)
        result = fn(*py_args)
        return convert_out(result, sig.ret_type) if sig else result

    def get_var(self, var_name: str) -> Any:
        if not hasattr(self._mod, var_name):
            raise LinkerError(f"Variable '{var_name}' no encontrada en '{self._path.name}'")
        return getattr(self._mod, var_name)

    def set_var(self, var_name: str, value: Any):
        setattr(self._mod, var_name, value)

    def unload(self):
        self._mod = None


# ════════════════════════════════════════════════════════════════════════
#  RUTA B (preparada) — JS fuente via QuickJS embebido
# ════════════════════════════════════════════════════════════════════════

def _load_quickjs():
    try:
        import quickjs
        return quickjs
    except ImportError:
        sys.stderr.write("[linker/js] quickjs no instalado.\n  pip install quickjs\n")
        sys.exit(1)


class _JSEngineQuickJS:
    def __init__(self):
        qjs = _load_quickjs()
        self._ctx = qjs.Context()

    def load(self, path: str):
        p = Path(path).resolve()
        if not p.exists():
            raise FileNotFoundError(f"Archivo JS no encontrado: {path}")
        code = p.read_text(encoding='utf-8')
        dir_js = str(p.parent).replace('\\', '\\\\')
        self._ctx.eval(f"var __dirname = '{dir_js}';")
        self._ctx.eval(code)

    def call(self, func_name: str, args: list):
        fn = self._ctx.eval(func_name)
        if not callable(fn):
            raise TypeError(f"'{func_name}' no es una funcion en el modulo JS")
        return self._to_python(fn(*args))

    def get(self, var_name: str):
        return self._to_python(self._ctx.eval(var_name))

    def set(self, var_name: str, value):
        self._ctx.eval(f"var {var_name} = {json.dumps(value)};")

    def _to_python(self, val):
        if val is None: return None
        if isinstance(val, (bool, int, float, str)): return val
        try:
            import quickjs
            if isinstance(val, quickjs.Object):
                raw = self._ctx.eval("JSON.stringify(_tess_tmp_)")
                self._ctx.eval("var _tess_tmp_ = undefined;")
                return json.loads(raw) if raw else None
        except Exception:
            pass
        return str(val)

    def unload(self):
        self._ctx = None


class _JSBridge:
    def __init__(self, path: Path):
        self._path = path
        self._lock = threading.Lock()
        self._sigs: dict = {}
        try:
            self._engine = _JSEngineQuickJS()
            self._mode   = 'embedded'
        except SystemExit:
            self._engine = _SubprocessBridge(
                path,
                cmd=['node', str(_DEPS_DIR / 'javascript' / 'tess_jsbridge.js')],
                runtime_name='Node.js (https://nodejs.org)',
            )
            self._mode = 'subprocess'
        self._engine.load(str(path))

    def define(self, func_name: str, ret_type: int, arg_types: list):
        self._sigs[func_name] = _Signature(int(ret_type), [int(t) for t in arg_types])

    def call(self, func_name: str, args: list) -> Any:
        sig = self._sigs.get(func_name)
        norm_args = [convert_in(a, t) for a, t in zip(args, sig.arg_types)] if sig else list(args)
        with self._lock:
            result = self._engine.call(func_name, norm_args)
        return convert_out(result, sig.ret_type) if sig else result

    def get_var(self, var_name: str) -> Any:
        with self._lock:
            return self._engine.get(var_name)

    def set_var(self, var_name: str, value: Any):
        with self._lock:
            self._engine.set(var_name, value)

    def unload(self):
        if hasattr(self._engine, 'unload'):
            self._engine.unload()


# ════════════════════════════════════════════════════════════════════════
#  RUTA B (preparada) — Lua fuente via LuaJIT embebido
# ════════════════════════════════════════════════════════════════════════

def _load_lupa():
    try:
        import lupa
        return lupa
    except ImportError:
        sys.stderr.write("[linker/lua] lupa no instalado.\n  pip install lupa\n")
        sys.exit(1)


class _LuaEngineLupa:
    def __init__(self):
        lupa = _load_lupa()
        self._lua = lupa.LuaRuntime(unpack_returned_tuples=True)
        self._lua.execute("require('math')")
        self._lua.execute("require('string')")
        self._lua.execute("require('table')")

    def load(self, path: str):
        p = Path(path).resolve()
        if not p.exists():
            raise FileNotFoundError(f"Archivo Lua no encontrado: {path}")
        self._lua.execute(p.read_text(encoding='utf-8'))

    def call(self, func_name: str, args: list):
        fn = self._lua.eval(func_name)
        if not callable(fn):
            raise TypeError(f"'{func_name}' no es una funcion en el modulo Lua")
        return self._to_python(fn(*args))

    def get(self, var_name: str):
        return self._to_python(self._lua.eval(var_name))

    def set(self, var_name: str, value):
        self._lua.globals()[var_name] = value

    def _to_python(self, val):
        if val is None: return None
        if isinstance(val, (bool, int, float, str)): return val
        try:
            import lupa
            if lupa.lua_type(val) == 'table':
                try:
                    return [self._to_python(val[i]) for i in range(1, len(val) + 1)]
                except Exception:
                    pass
                try:
                    return {k: self._to_python(v) for k, v in val.items()}
                except Exception:
                    pass
        except Exception:
            pass
        return str(val)

    def unload(self):
        self._lua = None


class _LuaBridge:
    def __init__(self, path: Path):
        self._path = path
        self._lock = threading.Lock()
        self._sigs: dict = {}
        try:
            self._engine = _LuaEngineLupa()
            self._mode   = 'embedded'
        except SystemExit:
            self._engine = _SubprocessBridge(
                path,
                cmd=['lua', str(_DEPS_DIR / 'lua' / 'tess_luabridge.lua')],
                runtime_name='Lua 5.4 (https://www.lua.org)',
            )
            self._mode = 'subprocess'
        self._engine.load(str(path))

    def define(self, func_name: str, ret_type: int, arg_types: list):
        self._sigs[func_name] = _Signature(int(ret_type), [int(t) for t in arg_types])

    def call(self, func_name: str, args: list) -> Any:
        sig = self._sigs.get(func_name)
        norm_args = [convert_in(a, t) for a, t in zip(args, sig.arg_types)] if sig else list(args)
        with self._lock:
            result = self._engine.call(func_name, norm_args)
        return convert_out(result, sig.ret_type) if sig else result

    def get_var(self, var_name: str) -> Any:
        with self._lock:
            return self._engine.get(var_name)

    def set_var(self, var_name: str, value: Any):
        with self._lock:
            self._engine.set(var_name, value)

    def unload(self):
        if hasattr(self._engine, 'unload'):
            self._engine.unload()


# ════════════════════════════════════════════════════════════════════════
#  Fallback generico: subprocess IPC via JSON (Node.js / Lua del sistema)
# ════════════════════════════════════════════════════════════════════════

class _SubprocessBridge:
    def __init__(self, path: Path, cmd: list, runtime_name: str):
        self._path = path
        self._lock = threading.Lock()
        try:
            self._proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True, bufsize=1,
            )
        except FileNotFoundError:
            raise LinkerError(
                f"Runtime no encontrado para '{path.name}'.\n"
                f"  Instala: {runtime_name}\n"
                f"  O instala el motor embebido Python: quickjs (JS) / lupa (Lua)"
            )

    def load(self, path: str):
        resp = self._ipc({'action': 'load', 'path': path})
        if not resp.get('ok'):
            raise LinkerError(f"Error cargando: {resp.get('error')}")

    def call(self, func_name: str, args: list) -> Any:
        resp = self._ipc({'action': 'call', 'func': func_name, 'args': args})
        if not resp.get('ok'):
            raise LinkerError(f"Error en '{func_name}': {resp.get('error')}")
        return resp.get('result')

    def get(self, var_name: str) -> Any:
        resp = self._ipc({'action': 'get', 'var': var_name})
        if not resp.get('ok'):
            raise LinkerError(f"No se pudo leer '{var_name}': {resp.get('error')}")
        return resp.get('result')

    def set(self, var_name: str, value: Any):
        resp = self._ipc({'action': 'set', 'var': var_name, 'value': value})
        if not resp.get('ok'):
            raise LinkerError(f"No se pudo escribir '{var_name}': {resp.get('error')}")

    def unload(self):
        try:
            self._ipc({'action': 'unload'})
            self._proc.stdin.close()
            self._proc.wait(timeout=3)
        except Exception:
            try:
                self._proc.kill()
            except Exception:
                pass

    def _ipc(self, cmd: dict) -> dict:
        with self._lock:
            self._proc.stdin.write(json.dumps(cmd) + '\n')
            self._proc.stdin.flush()
            line = self._proc.stdout.readline()
        if not line:
            raise LinkerError("Subproceso IPC cerro inesperadamente.")
        return json.loads(line.strip())


# ════════════════════════════════════════════════════════════════════════
#  RESOLUCION DE RUTA — archivo real o nombre lógico de sistema
# ════════════════════════════════════════════════════════════════════════

def _resolve_native_name(raw: str) -> Optional[str]:
    """
    Intenta resolver un nombre lógico de librería del sistema (ej. "m",
    "ssl", "crypto") al estilo ctypes.util.find_library, para no exigir
    SIEMPRE una ruta explícita. Devuelve None si no aplica/no se
    encontró — en ese caso el llamador sigue con el flujo normal
    (ruta de archivo) y reporta el error que corresponda.
    """
    if os.sep in raw or '/' in raw:
        return None  # ya parece una ruta, no un nombre suelto
    p = Path(raw)
    if p.suffix.lower() in _FFI_EXTS:
        return None  # ya trae extensión de precompilado, es ruta de archivo
    return ctypes.util.find_library(raw)


# ════════════════════════════════════════════════════════════════════════
#  DISPATCH UNICO
# ════════════════════════════════════════════════════════════════════════

def _make_bridge(path_input, calling_convention: str = "cdecl",
                  global_symbols: bool = False):
    raw = str(path_input)
    p = Path(raw)
    ext = p.suffix.lower()

    if ext in _FFI_EXTS or ext in _C_SRC_EXTS or ext in ('.py', '.js', '.lua'):
        if not p.exists():
            raise LinkerError(f"Archivo no encontrado: {raw}")
        if ext in _FFI_EXTS:    return _FFIBridge(p.resolve(), calling_convention, global_symbols)
        if ext in _C_SRC_EXTS:  return _CEngineBridge(p.resolve(), calling_convention, global_symbols)
        if ext == '.py':        return _PyBridge(p.resolve())
        if ext == '.js':        return _JSBridge(p.resolve())
        if ext == '.lua':       return _LuaBridge(p.resolve())

    # Sin extensión reconocida y no existe como archivo: puede ser un
    # nombre lógico de librería del sistema (ej. "m", "ssl", "crypto").
    found = _resolve_native_name(raw)
    if found:
        return _FFIBridge(Path(found), calling_convention, global_symbols)

    raise LinkerError(
        f"No se encontró '{raw}' como archivo ni como librería del sistema.\n"
        f"  Precompilado (libffi):        .so  .dll  .dylib  (o nombre lógico, ej. 'm')\n"
        f"  Codigo fuente (mini-motor):   .c  .o  .py  .js  .lua"
    )


# ════════════════════════════════════════════════════════════════════════
#  ESCANER DE HEADERS C — getHeader()
# ════════════════════════════════════════════════════════════════════════
#
# OBJETIVO: dado un .h (o una carpeta con varios), decir que funciones,
# variables extern, typedef y struct/union declara — y para cada una, la
# definicion recomendada YA armada con los mismos codigos LINKER_* que
# espera define()/defineStruct(), lista para usar tal cual.
#
# ALCANCE HONESTO: esto NO es un preprocesador de C completo. Cubre bien
# el caso comun de un header de biblioteca (prototipos de funcion,
# variables extern, typedef simples, struct/union con arreglos y
# bitfields, punteros a funcion como parametro/campo, y bloques
# #ifdef/#ifndef/#else/#endif alrededor de cualquiera de esas
# declaraciones). Lo que NO reconoce con certeza (una macro de anotacion
# rara, un tipo que no esta ni en la tabla base ni fue declarado antes en
# el mismo escaneo) se deja como el NOMBRE DE TIPO TAL CUAL aparece en el
# header (un string) en vez de adivinar un LINKER_* incorrecto — mismo
# criterio de honestidad que el resto de este archivo.
#
# #include y las lineas de preprocesador en si (#define, #pragma, etc.)
# nunca se reportan como entradas — pero SI se entra a mirar dentro de
# los bloques #ifdef/#ifndef/#else, y cualquier declaracion usable ahi
# adentro se reporta igual, con la condicion bajo la que vive anidada en
# la propia entrada (para que se sepa que esa firma es especifica de esa
# rama, ej. una version para _WIN32 y otra para el resto).

import re as _hdr_re

# Tipos base de C -> LINKER_* (para 'int'/'long' se usa el ancho REAL de
# la plataforma donde corre este proceso — decision basada en
# introspeccion real, no una adivinanza a ciegas).
_HDR_LONG_CODE   = LINKER_INT64 if ctypes.sizeof(ctypes.c_long) == 8 else LINKER_INT32
_HDR_ULONG_CODE  = LINKER_UINT64 if ctypes.sizeof(ctypes.c_ulong) == 8 else LINKER_UINT32
_HDR_SIZE_CODE   = LINKER_UINT64 if ctypes.sizeof(ctypes.c_size_t) == 8 else LINKER_UINT32
_HDR_SSIZE_CODE  = LINKER_INT64 if ctypes.sizeof(ctypes.c_ssize_t) == 8 else LINKER_INT32
_HDR_PTRINT_CODE = LINKER_UINT64 if ctypes.sizeof(ctypes.c_void_p) == 8 else LINKER_UINT32

_HDR_BASE_TYPES = {
    "void": LINKER_VOID,
    "char": LINKER_INT8, "signed char": LINKER_INT8,
    "unsigned char": LINKER_UINT8,
    "short": LINKER_INT16, "short int": LINKER_INT16, "signed short": LINKER_INT16,
    "unsigned short": LINKER_UINT16, "unsigned short int": LINKER_UINT16,
    "int": LINKER_INT32, "signed int": LINKER_INT32, "signed": LINKER_INT32,
    "unsigned int": LINKER_UINT32, "unsigned": LINKER_UINT32,
    "long": _HDR_LONG_CODE, "long int": _HDR_LONG_CODE, "signed long": _HDR_LONG_CODE,
    "unsigned long": _HDR_ULONG_CODE, "unsigned long int": _HDR_ULONG_CODE,
    "long long": LINKER_INT64, "long long int": LINKER_INT64,
    "unsigned long long": LINKER_UINT64, "unsigned long long int": LINKER_UINT64,
    "float": LINKER_FLOAT32, "double": LINKER_FLOAT, "long double": LINKER_LONGDOUBLE,
    "_Bool": LINKER_BOOL, "bool": LINKER_BOOL,
    "int8_t": LINKER_INT8, "int16_t": LINKER_INT16, "int32_t": LINKER_INT32, "int64_t": LINKER_INT64,
    "uint8_t": LINKER_UINT8, "uint16_t": LINKER_UINT16, "uint32_t": LINKER_UINT32, "uint64_t": LINKER_UINT64,
    "size_t": _HDR_SIZE_CODE, "ssize_t": _HDR_SSIZE_CODE,
    "uintptr_t": _HDR_PTRINT_CODE, "intptr_t": _HDR_SSIZE_CODE, "ptrdiff_t": _HDR_SSIZE_CODE,
    "wchar_t": LINKER_INT32,
}

# Macros de anotacion conocidas (convencion de llamada / export) que se
# descartan al parsear si aparecen antes del nombre de una funcion —
# ademas de estas, cualquier macro que matchee el patron de sufijo de
# _HDR_DECORATOR_SUFFIX_RE (ver mas abajo) se trata igual.
_HDR_KNOWN_DECORATORS = {
    "WINAPI", "CALLBACK", "APIENTRY", "__cdecl", "__stdcall", "__fastcall",
    "__declspec(dllimport)", "__declspec(dllexport)", "extern",
}

_HDR_PAREN_DECORATORS = ("__declspec(dllimport)", "__declspec(dllexport)")

_HDR_DECORATOR_SUFFIX_RE = _hdr_re.compile(
    r"\b[A-Z][A-Z0-9_]*_(API|EXPORT|EXTERN|DECL|CALL|ATTR|PUBLIC)\b"
)


# Cada codigo LINKER_* -> el string EXACTO que hay que escribir en
# Tesseract para pedir ese tipo, listo para copiar y pegar en
# define()/defineStruct(). Los que tienen constante con nombre en el
# modulo usan esa constante; los anchos especificos (INT8..UINT64,
# FLOAT32, LONGDOUBLE, ENUM, COMPLEX64/128, VEC128F/D, VEC256F/D) NO
# tienen constante propia — se piden con el atributo FFI correspondiente
# sobre un valor base (0._int32, 0.0._float32, etc.), asi que se muestra
# esa forma en vez de un numero pelado que nadie mas que este bridge
# entiende.
_HDR_TYPE_CODE_TO_EXPR = {
    LINKER_INT:        "INT",
    LINKER_FLOAT:      "FLOAT",
    LINKER_STRING:     "STRING",
    LINKER_POINTER:    "POINTER",
    LINKER_VOID:       "VOID",
    LINKER_BOOL:       "BOOL",
    LINKER_WSTRING:    "WSTRING",
    LINKER_INT8:       "0._int8",
    LINKER_INT16:      "0._int16",
    LINKER_INT32:      "0._int32",
    LINKER_INT64:      "0._int64",
    LINKER_UINT8:      "0._uint8",
    LINKER_UINT16:     "0._uint16",
    LINKER_UINT32:     "0._uint32",
    LINKER_UINT64:     "0._uint64",
    LINKER_FLOAT32:    "0.0._float32",
    LINKER_LONGDOUBLE: "0.0._longdouble",
    LINKER_COMPLEX64:  "0.0._complex64",
    LINKER_COMPLEX128: "0.0._complex128",
    LINKER_ENUM:       "0._enum",
    LINKER_VEC128F:    "0.0._vec128f",
    LINKER_VEC128D:    "0.0._vec128d",
    LINKER_VEC256F:    "0.0._vec256f",
    LINKER_VEC256D:    "0.0._vec256d",
}


def _hdr_type_expr(code):
    """Traduce un codigo LINKER_* al string real que hay que escribir en
    Tesseract para pedirlo — nunca se deja el numero pelado."""
    return _HDR_TYPE_CODE_TO_EXPR.get(code, code)


class _HdrType:
    """
    Un tipo ya resuelto (o no) dentro del header. 'code' es un LINKER_*
    cuando se pudo resolver con certeza; 'ref' es el nombre de un
    struct/union/typedef YA visto en este mismo escaneo (referencia
    anidada); si ninguno aplica, 'raw' guarda el texto de tipo tal cual
    aparecia en el header (honesto: no se adivina).
    """
    __slots__ = ("code", "ref", "raw", "pointer_depth", "is_callback", "callback_sig")

    def __init__(self, code=None, ref=None, raw=None, pointer_depth=0,
                 is_callback=False, callback_sig=None):
        self.code = code
        self.ref = ref
        self.raw = raw
        self.pointer_depth = pointer_depth
        self.is_callback = is_callback
        self.callback_sig = callback_sig

    def to_map_value(self):
        if self.is_callback:
            ret, params = self.callback_sig
            return ["callback", ret.to_map_value(), [p.to_map_value() for p in params]]
        if self.pointer_depth > 0:
            if self.code == LINKER_INT8 and self.pointer_depth == 1:
                return "linker.STRING"       # char* / const char*
            if self.raw and "wchar_t" in self.raw and self.pointer_depth == 1:
                return "linker.WSTRING"
            if self.code == LINKER_VOID and self.pointer_depth == 1:
                return "linker.POINTER"
            if self.ref is not None:
                return ["ptr", self.ref]
            if self.code is not None:
                return ["ptr", _hdr_type_expr(self.code)]
            return ["ptr", self.raw]
        if self.ref is not None:
            return self.ref
        if self.code is not None:
            return _hdr_type_expr(self.code)
        return self.raw


def _hdr_strip_comments(text: str) -> str:
    out = []
    i, n = 0, len(text)
    while i < n:
        if text[i:i+2] == "/*":
            j = text.find("*/", i + 2)
            j = n if j == -1 else j + 2
            out.append("\n" * text.count("\n", i, j))
            i = j
        elif text[i:i+2] == "//":
            j = text.find("\n", i)
            j = n if j == -1 else j
            i = j
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def _hdr_strip_header_guard(text: str) -> str:
    """
    El patron clasico '#ifndef X / #define X ... #endif' que envuelve TODO
    el archivo es una convencion de compilacion (evitar doble inclusion),
    no una condicion real de plataforma/feature — sin este paso, CADA
    declaracion del header terminaria marcada con una condicion falsa
    ('!X') que no aporta nada util. Se detecta por posicion (las dos
    primeras lineas de preprocesador del archivo) y se elimina junto con
    su '#endif' final, antes de tagear condiciones de verdad.
    """
    lines = text.split("\n")
    idxs = [i for i, l in enumerate(lines) if l.strip().startswith("#")]
    if len(idxs) < 2:
        return text
    i0, i1 = idxs[0], idxs[1]
    m0 = _hdr_re.match(r"#\s*ifndef\s+(" + r"[A-Za-z_][A-Za-z0-9_]*" + r")", lines[i0].strip())
    m1 = _hdr_re.match(r"#\s*define\s+(" + r"[A-Za-z_][A-Za-z0-9_]*" + r")", lines[i1].strip())
    if not (m0 and m1 and m0.group(1) == m1.group(1)):
        return text
    last_endif = None
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].strip().startswith("#") and lines[i].strip().replace(" ", "").startswith("#endif"):
            last_endif = i
            break
    if last_endif is None or last_endif <= i1:
        return text
    lines[i0] = ""
    lines[i1] = ""
    lines[last_endif] = ""
    return "\n".join(lines)


def _hdr_strip_extern_c_wrapper(text: str) -> str:
    """
    'extern \"C\" { ... }' envolviendo TODO el archivo (el patron clasico
    de cualquier header pensado para usarse desde C++) es, para estos
    fines, otro wrapper transparente — igual que el include guard: dado
    que el conteo de profundidad de _hdr_split_statements es GLOBAL a
    todo el archivo, esta llave abierta nunca vuelve a 0 mientras siga
    abierta, y nada de lo que hay adentro llega a cerrarse nunca como
    sentencia propia. Se detecta la apertura ('extern \"C\" {' sola en su
    linea) y se blanquea, junto con la ULTIMA linea que sea solo '}' en
    el archivo (la convencion real es que esta envoltura llega hasta
    practicamente el final del header).
    """
    lines = text.split("\n")
    open_idx = None
    for i, l in enumerate(lines):
        if _hdr_re.match(r'^\s*extern\s+"C"\s*\{\s*$', l):
            open_idx = i
            break
    if open_idx is None:
        return text
    close_idx = None
    for i in range(len(lines) - 1, open_idx, -1):
        if lines[i].strip() == "}":
            close_idx = i
            break
    if close_idx is None:
        return text
    lines[open_idx] = ""
    lines[close_idx] = ""
    return "\n".join(lines)


def _hdr_tag_conditions(text: str):
    """
    Recorre linea por linea manteniendo una pila de condiciones activas
    de #ifdef/#ifndef/#if/#else/#elif/#endif. Devuelve una lista de
    (linea, condicion) — condicion es None fuera de cualquier bloque, o
    una tupla con la(s) condicion(es) activas (de afuera hacia adentro)
    cuando la linea vive dentro de uno o mas bloques anidados.
    #include/#define/#pragma/#undef/etc. se descartan (no se emiten).
    """
    stack = []
    out = []
    for line in text.split("\n"):
        stripped = line.strip()
        if stripped.startswith("#"):
            direct = stripped[1:].strip()
            if direct.startswith("ifdef"):
                stack.append(direct[len("ifdef"):].strip())
            elif direct.startswith("ifndef"):
                stack.append("!" + direct[len("ifndef"):].strip())
            elif direct.startswith("if"):
                stack.append(direct[len("if"):].strip())
            elif direct.startswith("elif"):
                if stack:
                    stack[-1] = direct[len("elif"):].strip()
            elif direct.startswith("else"):
                if stack:
                    cond = stack[-1]
                    stack[-1] = ("!(" + cond + ")") if not cond.startswith("!") else cond[1:]
            elif direct.startswith("endif"):
                if stack:
                    stack.pop()
            continue
        out.append((line, tuple(stack) if stack else None))
    return out


def _hdr_split_statements(tagged_lines):
    """
    Reagrupa las lineas ya tageadas (ver _hdr_tag_conditions) en
    "sentencias" logicas completas: se acumula texto hasta que la
    profundidad de {}/() vuelve a 0 en un ';', o hasta que se cierra una
    llave de nivel 0 (struct/union/enum/cuerpo de funcion). Cada
    sentencia conserva la condicion vigente en la linea donde EMPEZO.
    """
    stmts = []
    buf = []
    depth = 0
    cond_of_stmt = None
    started = False
    for line, cond in tagged_lines:
        if not started and line.strip():
            cond_of_stmt = cond
            started = True
        buf.append(line)
        for ch in line:
            if ch in "{(":
                depth += 1
            elif ch in "})":
                depth = max(0, depth - 1)
            elif ch == ";" and depth == 0:
                stmt_text = "\n".join(buf).strip()
                if stmt_text:
                    stmts.append((stmt_text, cond_of_stmt))
                buf = []
                started = False
        if depth == 0 and buf and buf[-1].rstrip().endswith("}"):
            stmt_text = "\n".join(buf).strip()
            if stmt_text:
                stmts.append((stmt_text, cond_of_stmt))
            buf = []
            started = False
    if buf and "".join(buf).strip():
        stmts.append(("\n".join(buf).strip(), cond_of_stmt))
    return stmts


_HDR_IDENT = r"[A-Za-z_][A-Za-z0-9_]*"
_HDR_FUNCPTR_RE = _hdr_re.compile(
    r"^(?P<ret>[\w\s\*]+?)\(\s*[\*]\s*(?P<name>" + _HDR_IDENT + r")\s*\)\s*\((?P<params>.*)\)$"
)


def _hdr_normalize_type_text(txt: str) -> str:
    txt = _hdr_re.sub(r"\bconst\b", "", txt)
    txt = _hdr_re.sub(r"\bvolatile\b", "", txt)
    for dec in _HDR_KNOWN_DECORATORS:
        txt = txt.replace(dec, "")
    # Macros de export/linkage propias de cada proyecto (JS_EXTERN,
    # MYLIB_API, FOO_DECL, etc.) — se reconocen por el SUFIJO del
    # nombre, no por mayusculas en general (eso arriesgaria tipos reales
    # como DWORD/BOOL/HANDLE de headers de Windows, que tambien son
    # todo-mayusculas pero SI son tipos de verdad).
    txt = _HDR_DECORATOR_SUFFIX_RE.sub("", txt)
    txt = _hdr_re.sub(r"\s+", " ", txt).strip()
    return txt


def _hdr_resolve_type(txt: str, known: dict) -> "_HdrType":
    """known: dict nombre -> _HdrType, de structs/unions/typedefs YA
    vistos en este mismo escaneo (para poder anidar referencias)."""
    txt = _hdr_normalize_type_text(txt)
    ptr_depth = txt.count("*")
    base = txt.replace("*", "").strip()
    base = _hdr_re.sub(r"\bstruct\b|\bunion\b|\benum\b", "", base).strip()
    base = _hdr_re.sub(r"\s+", " ", base)
    if base in _HDR_BASE_TYPES:
        return _HdrType(code=_HDR_BASE_TYPES[base], raw=txt, pointer_depth=ptr_depth)
    if base in known:
        known_t = known[base]
        if known_t.is_callback:
            return _HdrType(is_callback=True, callback_sig=known_t.callback_sig, raw=txt)
        return _HdrType(ref=base, raw=txt, pointer_depth=ptr_depth)
    if ptr_depth > 0:
        return _HdrType(code=LINKER_POINTER, raw=txt, pointer_depth=ptr_depth)
    return _HdrType(raw=base or txt, pointer_depth=ptr_depth)


def _hdr_split_params(params_txt: str) -> list:
    params_txt = params_txt.strip()
    if not params_txt or params_txt == "void":
        return []
    parts, depth, cur = [], 0, []
    for ch in params_txt:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    if cur:
        parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]


def _hdr_parse_param(p: str, known: dict) -> "_HdrType":
    m = _HDR_FUNCPTR_RE.match(p.strip())
    if m:
        ret_t = _hdr_resolve_type(m.group("ret"), known)
        sub_params = [_hdr_parse_param(sp, known) for sp in _hdr_split_params(m.group("params"))]
        return _HdrType(is_callback=True, callback_sig=(ret_t, sub_params), raw=p)
    p = _hdr_re.sub(r"\b" + _HDR_IDENT + r"\s*$", "", p.strip()) if _hdr_re.search(
        r"[\w\*]\s+" + _HDR_IDENT + r"\s*$", p.strip()) else p.strip()
    p = _hdr_re.sub(r"\[\s*\d*\s*\]\s*$", " *", p)
    return _hdr_resolve_type(p, known)


def _hdr_parse_function(stmt: str, known: dict):
    m = _hdr_re.match(r"^(?P<ret>[\w\s\*]+?)\b(?P<name>" + _HDR_IDENT + r")\s*\((?P<params>.*)\)\s*(\{.*\})?$",
                       stmt, _hdr_re.DOTALL)
    if not m:
        return None
    name = m.group("name")
    ret_txt = _hdr_normalize_type_text(m.group("ret"))
    if not ret_txt or ret_txt.split()[-1] in _HDR_KNOWN_DECORATORS:
        return None
    ret_t = _hdr_resolve_type(ret_txt, known)
    params_txt = m.group("params")
    param_list = _hdr_split_params(params_txt)
    params = [_hdr_parse_param(p, known) for p in param_list]
    return name, ret_t, params


def _hdr_parse_aggregate(stmt: str, kind: str, known: dict):
    """struct/union {campos...} NombreOpcional — devuelve
    (nombre_o_None, [(campo,tipo,longitud,bits), ...])."""
    m = _hdr_re.search(r"\{(.*)\}\s*(" + _HDR_IDENT + r")?\s*$", stmt, _hdr_re.DOTALL)
    if not m:
        return None
    body, tail_name = m.group(1), m.group(2)
    head = stmt[:m.start()]
    tag_m = _hdr_re.search(r"\b" + kind + r"\s+(" + _HDR_IDENT + r")", head)
    agg_name = tail_name or (tag_m.group(1) if tag_m else None)
    fields = []
    for fline in body.split(";"):
        fline = fline.strip()
        if not fline:
            continue
        bits = None
        if ":" in fline and "?" not in fline:
            fpart, bpart = fline.rsplit(":", 1)
            if bpart.strip().isdigit():
                fline, bits = fpart.strip(), int(bpart.strip())
        fm = _hdr_re.match(r"^(?P<t>[\w\s\*]+?)\b(?P<n>" + _HDR_IDENT + r")\s*(\[\s*(?P<len>\d*)\s*\])?$", fline)
        if not fm:
            continue
        ftype = _hdr_resolve_type(fm.group("t"), known)
        flen = int(fm.group("len")) if fm.group("len") else None
        fields.append((fm.group("n"), ftype, flen, bits))
    return agg_name, fields


def _hdr_strip_paren_decorators(stmt: str) -> str:
    """Decoradores como __declspec(dllimport) traen parentesis PROPIOS
    que rompen los regex de funcion/variable si se dejan en el medio del
    tipo de retorno — se sacan antes de intentar parsear nada."""
    for dec in _HDR_PAREN_DECORATORS:
        stmt = stmt.replace(dec, " ")
    return stmt


def scan_c_header(path: Path) -> dict:
    """Escanea un .h (o todos los .h de una carpeta, recursivo) y
    devuelve el mapa {nombre: [...]} descripto en getHeader()."""
    files = [path] if path.is_file() else sorted(path.rglob("*.h"))
    result = {}
    known: dict = {}

    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        text = _hdr_strip_comments(text)
        text = _hdr_strip_header_guard(text)
        text = _hdr_strip_extern_c_wrapper(text)
        tagged = _hdr_tag_conditions(text)
        for stmt, cond in _hdr_split_statements(tagged):
            stmt = stmt.strip()
            if not stmt:
                continue
            stmt = _hdr_strip_paren_decorators(stmt).strip()

            if stmt.startswith("typedef"):
                body = stmt[len("typedef"):].strip().rstrip(";").rstrip()
                if _hdr_re.match(r"^(struct|union|enum)\b", body) and "{" in body:
                    kind = body.split()[0]
                    agg = _hdr_parse_aggregate(body, kind, known)
                    if agg:
                        _, fields = agg
                        after_brace = body[body.rfind("}") + 1:].strip()
                        alias = after_brace or (agg[0] if agg[0] else None)
                        if alias:
                            entry = [kind, [[n, t.to_map_value(), l, b] for (n, t, l, b) in fields], cond]
                            result[alias] = entry
                            known[alias] = _HdrType(ref=alias)
                    continue
                fm = _HDR_FUNCPTR_RE.match(body)
                if fm:
                    alias = fm.group("name")
                    ret_t = _hdr_resolve_type(fm.group("ret"), known)
                    sub_params = [_hdr_parse_param(sp, known) for sp in _hdr_split_params(fm.group("params"))]
                    cb_type = _HdrType(is_callback=True, callback_sig=(ret_t, sub_params))
                    result[alias] = ["typedef", cb_type.to_map_value(), cond]
                    known[alias] = cb_type
                    continue
                m = _hdr_re.match(r"^(?P<t>[\w\s\*]+?)\b(?P<n>" + _HDR_IDENT + r")$", body)
                if m:
                    alias, t = m.group("n"), _hdr_resolve_type(m.group("t"), known)
                    result[alias] = ["typedef", t.to_map_value(), cond]
                    known[alias] = t if (t.code is None and t.ref is None) else t
                    if t.ref is None and t.code is not None:
                        known[alias] = _HdrType(code=t.code)
                continue

            if _hdr_re.match(r"^(struct|union|enum)\b", stmt) and "{" in stmt:
                kind = stmt.split()[0]
                agg = _hdr_parse_aggregate(stmt.rstrip(";").rstrip(), kind, known)
                if agg and agg[0]:
                    name, fields = agg
                    entry = [kind, [[n, t.to_map_value(), l, b] for (n, t, l, b) in fields], cond]
                    result[name] = entry
                    known[name] = _HdrType(ref=name)
                continue

            if "(" in stmt and not stmt.rstrip().endswith(";") is False:
                parsed = _hdr_parse_function(stmt.rstrip(";").rstrip(), known)
                if parsed:
                    name, ret_t, params = parsed
                    result[name] = ["function", ret_t.to_map_value(),
                                    [p.to_map_value() for p in params], cond]
                    continue

            m = _hdr_re.match(r"^(extern\s+)?(?P<t>[\w\s\*]+?)\b(?P<n>" + _HDR_IDENT + r")\s*(\[\s*(?P<len>\d*)\s*\])?$",
                               stmt.rstrip(";").strip())
            if m and m.group("t").strip():
                t = _hdr_resolve_type(m.group("t"), known)
                flen = int(m.group("len")) if m.group("len") else None
                entry = ["variable", t.to_map_value(), cond] if flen is None else \
                        ["variable", t.to_map_value(), flen, cond]
                result[m.group("n")] = entry
    return result


# ════════════════════════════════════════════════════════════════════════
#  LinkerObject
# ════════════════════════════════════════════════════════════════════════

class LinkerObject:
    def __init__(self, path: str, calling_convention: str = "cdecl",
                 global_symbols: bool = False):
        """
        calling_convention: "cdecl" (por defecto, sirve para casi todo) o
        "stdcall" — solo aplica en Windows, y solo hace falta indicarlo si
        el binario (típicamente de 32 bits, estilo WINAPI) se compiló
        explícitamente con esa convención. Ponerla mal no da un error
        claro: corrompe la pila en silencio, así que nunca se adivina sola.

        global_symbols: expone los símbolos de esta librería a TODO el
        proceso (RTLD_GLOBAL) en vez de solo a sí misma (RTLD_LOCAL, el
        default de siempre) — hace falta cuando otro precompilado que
        cargues después necesita resolver símbolos contra este.
        """
        self._path = Path(str(path))
        if calling_convention is None:
            calling_convention = "cdecl"
        if global_symbols is None:
            global_symbols = False
        self._bridge = _make_bridge(path, calling_convention, global_symbols)
        self._loaded = True

    def defineStruct(self, struct_name, fields, pack=None, as_tuple=False):
        """
        Declara la forma de un dict/tupla/arreglo que vas a pasar o recibir
        del precompilado. fields: lista de (nombre_o_indice, tipo,
        longitud=None, bits=None). 'tipo' puede ser INT/FLOAT/STRING/
        WSTRING/POINTER/BOOL, un valor marcado con un atributo FFI (ej.
        0._int32, 0.0._float32 — ver interpre.py) para pedir un ancho
        específico, el nombre de otro struct/union ya declarado (anidado),
        o linker.ptr(tipo) para un campo puntero tipado.
        pack: fuerza alineación (equivalente a #pragma pack(N)).
        as_tuple: si True, este struct se lee como tupla en vez de dict.
        Después de esto, define()/vr()/set() con ese mismo nombre de tipo
        ya saben convertir tu dict/tupla de ida y vuelta automáticamente.
        """
        self._check()
        norm = [(f[0], _coerce_type_spec(f[1])) + tuple(f[2:]) for f in fields]
        self._bridge.define_struct(str(struct_name), norm,
                                    pack=int(pack) if pack else None,
                                    as_tuple=bool(as_tuple))

    def defineUnion(self, union_name, fields, pack=None, as_tuple=False):
        """
        Igual que defineStruct() pero para 'union' de C: todos los campos
        comparten la misma dirección de memoria.
        """
        self._check()
        norm = [(f[0], _coerce_type_spec(f[1])) + tuple(f[2:]) for f in fields]
        self._bridge.define_union(str(union_name), norm,
                                   pack=int(pack) if pack else None,
                                   as_tuple=bool(as_tuple))

    def fn(self, func_name, *args):
        self._check()
        if len(args) == 1 and isinstance(args[0], list):
            args = args[0]
        else:
            args = list(args)
        return self._bridge.call(str(func_name), args)

    def vr(self, var_name, type_code=None, length=None):
        self._check()
        tc = _coerce_type_spec(type_code) if type_code is not None else None
        return self._bridge.get_var(str(var_name), tc, int(length) if length else None)

    def set(self, var_name, value, type_code=None, length=None):
        self._check()
        tc = _coerce_type_spec(type_code) if type_code is not None else None
        self._bridge.set_var(str(var_name), value, tc, int(length) if length else None)

    def defineVar(self, var_name, type_code, length=None):
        """
        Declara de antemano el tipo real (INT/FLOAT/STRING/POINTER/BOOL,
        cualquier ancho, nombre de struct/union, o Ptr) y, si aplica, la
        longitud (para arreglos) de una variable exportada por el
        precompilado. Igual que define() pero para datos en vez de
        funciones. Después de llamar esto una vez, vr()/set() ya no
        necesitan que les pases el tipo cada vez.
        """
        self._check()
        self._bridge.define_var(str(var_name), _coerce_type_spec(type_code),
                                 int(length) if length else None)

    # Alias retrocompatibles — 'func' y 'var' son palabras reservadas en
    # Tesseract (declaración de funciones/variables), por eso el atajo usa
    # fn()/vr(), pero se mantienen aquí por si algo externo a Tesseract
    # llama a este bridge directamente desde Python.
    func = fn
    var = vr

    def define(self, func_name, ret_type, types, variadic=False,
               callingConvention=None, thiscall=False):
        """
        callingConvention: None (por defecto) usa la convención general
          fijada al abrir la biblioteca. "cdecl" o "stdcall" fuerza OTRA
          convención SOLO para esta función, sin afectar a las demás
          definidas sobre la misma biblioteca (útil si una .dll mezcla
          funciones cdecl y stdcall, algo poco común pero real en
          algunas APIs viejas de Windows).
        thiscall: True marca esta función como método de C++ (this
          pasado en ECX, no por pila). Solo soportado en Windows de 32
          bits — en 64 bits, y en Linux/macOS, 'thiscall' no existe como
          convención distinta y no hace falta marcar nada: alcanza con
          declarar el primer argumento como Ptr(...)/POINTER normal.
        """
        self._check()
        if not isinstance(types, list):
            types = [types]
        self._bridge.define(str(func_name),
                             _coerce_type_spec(ret_type),
                             [_coerce_type_spec(t) for t in types],
                             variadic=bool(variadic),
                             calling_convention=callingConvention,
                             thiscall=bool(thiscall))

    def loadDir(self, path, subdir=False):
        """
        Carga de una sola vez todas las bibliotecas precompiladas
        (.so/.dll/.dylib) que haya en 'path'. subdir=false (por defecto)
        solo mira el nivel superior de 'path'; subdir=true entra también
        a las subcarpetas. No reemplaza la biblioteca principal de este
        LinkerObject: las cargadas así quedan como fuente adicional de
        símbolos para define()/fn()/vr(), sin necesidad de abrir un
        LinkerObject nuevo por cada archivo.
        Devuelve {"loaded": [...], "failed": [...]}.
        Solo aplica a librerías precompiladas (.so/.dll/.dylib).
        """
        self._check()
        if not hasattr(self._bridge, 'load_dir'):
            raise LinkerError(
                "loadDir() solo aplica a librerías precompiladas "
                "(.so/.dll/.dylib)."
            )
        return self._bridge.load_dir(str(path), bool(subdir))

    def getHeader(self, path):
        """
        Escanea un archivo .h (o una carpeta completa, recursivo) y
        devuelve un dict {nombre: [...]} con TODO lo declarado que se
        pueda usar — funciones, variables extern, typedef, struct/union —
        con la definición recomendada ya armada usando los mismos
        códigos LINKER_* que esperan define()/defineStruct(). No define
        ni carga nada por su cuenta: solo informa, la decisión de qué
        define()/defineStruct() llamar queda de tu lado.

        Formato de cada entrada:
          función:  [nombre] = ["function", tipo_retorno, [tipos_parametros], condicion]
          variable: [nombre] = ["variable", tipo, condicion]  (o con longitud
                     de arreglo como 3er elemento si aplica)
          typedef:  [nombre] = ["typedef", tipo_resuelto, condicion]
          struct/
          union:    [nombre] = ["struct"|"union",
                                 [[campo, tipo, longitud, bits], ...], condicion]

        'tipo'/'tipo_retorno' es un código LINKER_* cuando se resolvió
        con certeza; ["ptr", tipo_o_nombre] para un puntero tipado;
        ["callback", tipo_retorno, [tipos_parametros]] para un puntero a
        función; el nombre de otro struct/union/typedef YA visto en este
        mismo escaneo, como referencia anidada; o el texto de tipo tal
        cual aparece en el header, cuando no se pudo resolver con
        certeza (nunca se adivina un LINKER_* incorrecto).

        'condicion' es None si la declaración no está dentro de ningún
        #ifdef/#ifndef, o una tupla con la(s) condición(es) activas
        (de afuera hacia adentro) cuando sí lo está — por ejemplo,
        ('_WIN32',) para algo dentro de un #ifdef _WIN32, o
        ('!(_WIN32)',) para su rama #else.
        """
        self._check()
        p = Path(str(path))
        if not p.exists():
            raise LinkerError(f"getHeader(): no existe '{path}'.")
        return scan_c_header(p)

    def lastError(self):
        """
        Estado de error del sistema (errno/GetLastError) tras la última
        llamada nativa. Solo aplica a librerías precompiladas.
        """
        self._check()
        if not hasattr(self._bridge, 'last_error'):
            raise LinkerError(
                "lastError() solo aplica a librerías precompiladas "
                "(.so/.dll/.dylib)."
            )
        return self._bridge.last_error()

    def unload(self):
        if self._loaded:
            self._bridge.unload()
            self._loaded = False

    def _check(self):
        if not self._loaded:
            raise LinkerError("LinkerObject no esta activo. ¿Llamaste unload() antes de tiempo?")

    def __repr__(self):
        return (f"<LinkerObject path='{self._path.name}' "
                f"bridge={type(self._bridge).__name__} loaded={self._loaded}>")

    def __del__(self):
        if getattr(self, '_loaded', False):
            try:
                self.unload()
            except Exception:
                pass


# ════════════════════════════════════════════════════════════════════════
#  Funciones globales + bridge functions __linker_*
# ════════════════════════════════════════════════════════════════════════

def linker_load(path: str, calling_convention: str = "cdecl",
                 global_symbols: bool = False) -> LinkerObject:
    # None/null explícito == "usar el default" — Tesseract no soporta
    # parámetros opcionales en la declaración de función, así que el lado
    # Tesseract expone estos parámetros como REQUERIDOS pero tolera pasar
    # null para pedir el comportamiento por defecto (igual que ya hacen
    # type_code/length en vr()/set()/defineVar()).
    if calling_convention is None:
        calling_convention = "cdecl"
    if global_symbols is None:
        global_symbols = False
    return LinkerObject(path, calling_convention, global_symbols)


def linker_load_deps(path: str) -> None:
    p = Path(path)
    if not p.exists():
        raise LinkerError(f"Directorio de dependencias no encontrado: {path}")
    dep_str = str(p.resolve())
    os.environ['TESS_LINKER_DEPS'] = dep_str
    sys.path.insert(0, dep_str)
    os.environ['NODE_PATH'] = dep_str + os.pathsep + os.environ.get('NODE_PATH', '')

    # ── Dependencias NATIVAS: un .so/.dll/.dylib que vayas a cargar puede
    #    a su vez depender de OTRO .so/.dll/.dylib que viva aquí. Ajustar
    #    solo sys.path/NODE_PATH (arriba) no sirve para eso — hace falta
    #    resolver la búsqueda de librerías nativas del propio SO.
    if sys.platform == 'win32':
        # add_dll_directory (Python 3.8+) SÍ afecta las búsquedas de
        # LoadLibrary que se hagan DESPUÉS de esta llamada — a diferencia
        # de PATH, que el loader de Windows moderno ya no consulta por
        # defecto para resolver dependencias de una DLL.
        try:
            os.add_dll_directory(dep_str)
        except (AttributeError, OSError):
            pass
        os.environ['PATH'] = dep_str + os.pathsep + os.environ.get('PATH', '')
    else:
        # En Linux/macOS, LD_LIBRARY_PATH/DYLD_LIBRARY_PATH ya NO afectan
        # a un proceso que ya arrancó (el runtime linker solo los lee al
        # inicio). El fix real es precargar aquí mismo, con RTLD_GLOBAL,
        # cada .so/.dylib que haya en deps/ ANTES de cargar la librería
        # principal — así sus símbolos quedan disponibles globalmente y
        # el dlopen posterior de la librería principal resuelve sus
        # dependencias transitivas contra estos.
        for f in sorted(p.iterdir()):
            if f.is_file() and (f.suffix.lower() in ('.so', '.dylib') or '.so.' in f.name):
                try:
                    ctypes.CDLL(str(f), mode=ctypes.RTLD_GLOBAL)
                except OSError:
                    pass
        # Se dejan también las variables de entorno por si algo (un
        # subproceso, por ejemplo _SubprocessBridge) sí las respeta.
        os.environ['LD_LIBRARY_PATH']   = dep_str + os.pathsep + os.environ.get('LD_LIBRARY_PATH', '')
        os.environ['DYLD_LIBRARY_PATH'] = dep_str + os.pathsep + os.environ.get('DYLD_LIBRARY_PATH', '')


def linker_create(path: str, calling_convention: str = "cdecl",
                   global_symbols: bool = False):
    if calling_convention is None:
        calling_convention = "cdecl"
    if global_symbols is None:
        global_symbols = False
    return _make_bridge(path, calling_convention, global_symbols)


def linker_ptr(base_type) -> Ptr:
    """Construye un puntero TIPADO para usar en define()/defineStruct()/defineVar()."""
    return Ptr(_coerce_type_spec(base_type))


def linker_out(base_type, size=None) -> Out:
    """Construye un marcador de parámetro de SALIDA para usar en define()."""
    return Out(_coerce_type_spec(base_type), int(size) if size else None)


def linker_aligned(base_type, align=16) -> Aligned:
    """
    Construye un marcador de argumento PUNTERO con alineación forzada
    (16 por defecto, pensado para SSE; 32 para AVX) — para usar en
    define() cuando un tipo vectorial viaja detrás de un puntero en la
    firma de una función C.
    """
    return Aligned(_coerce_type_spec(base_type), int(align))


def linker_callback_signature(ref, return_type=None, param_types=None):
    """
    Fuerza la firma EXACTA del callback nativo que se arme a partir de
    'ref' (una referencia a función, myFunc(...).algo) — necesario cuando
    el ABI real de C usa anchos que no calzan con los tipos DECLARADOS de
    la función Tesseract, sobre todo por parámetro: ._int32/._float32 en
    la propia referencia solo pueden marcar el RETORNO completo, nunca un
    parámetro individual (un atributo no lleva argumentos, así que no hay
    forma de decir a la vez "qué parámetro" y "qué ancho" con uno solo).

    return_type: un código LINKER_* (INT/FLOAT/STRING/BOOL/VOID/POINTER,
      o cualquiera de los anchos internos) — o None para no tocarlo (deja
      lo que ya tenía la referencia).
    param_types: lista de códigos LINKER_*, en el MISMO ORDEN que los
      parámetros declarados de la función — o None para no tocar nada.

    Devuelve una referencia NUEVA (nunca muta la que se le pasó).
    """
    if not _is_function_ref(ref):
        raise LinkerError(
            "linker.callbackSignature() solo aplica a una referencia a "
            "función (miFunc(...).algo), no a un valor cualquiera."
        )
    new_ref = copy.copy(ref)
    sig = dict(getattr(ref, 'callback_signature', None) or {})
    if return_type is not None:
        sig['return'] = int(return_type)
    if param_types is not None:
        sig['params'] = [int(t) for t in param_types]
    new_ref.callback_signature = sig
    return new_ref


def linker_callback(ret_type, arg_types) -> Callback:
    """
    Construye un marcador Callback(ret_type, arg_types) para declarar que
    un retorno de define() (o un campo de defineStruct()) es un PUNTERO A
    FUNCIÓN con esta firma exacta — usar cuando el BINARIO devuelve un
    puntero a función (el sentido contrario a pasar una función Tesseract
    como callback hacia C).
    """
    return Callback(_coerce_type_spec(ret_type), [_coerce_type_spec(t) for t in arg_types])


def linker_native_callback_fn(native_callback: NativeCallback, *args) -> Any:
    """Invoca un NativeCallback (puntero a función devuelto por un binario) con los argumentos dados."""
    if len(args) == 1 and isinstance(args[0], list):
        args = args[0]
    else:
        args = list(args)
    return native_callback.fn(*args)


def linker_obj_fn(bridge, func_name: str, *args) -> Any:
    if len(args) == 1 and isinstance(args[0], list):
        args = args[0]
    else:
        args = list(args)
    return bridge.call(str(func_name), args)


def _coerce_type_spec(t):
    """
    Un 'tipo' (para define()/defineVar()/defineStruct()/defineUnion())
    puede llegar como:
      - número: primitivo (INT/FLOAT/STRING/WSTRING/POINTER/BOOL — las
        únicas constantes con nombre que expone el módulo).
      - un valor MARCADO desde Tesseract con un atributo FFI (ej. 0._int32,
        0.0._float32 — ver el bloque de atributos FFI en interpre.py): se
        traduce via _FFI_KIND_TO_LINKER al código LINKER_* interno que le
        corresponde. Es la única forma de pedir un ancho específico
        (int8/16/32/64, uint8/16/32/64, float32, longdouble) — no hay
        constantes INT32/FLOAT32/etc. con nombre en el módulo.
      - string: nombre de un struct/union ya declarado con
        defineStruct()/defineUnion().
      - Ptr(...) / Out(...) / Callback(...): se dejan pasar tal cual, ya
        vienen resueltos (los arma linker_ptr()/linker_out()/
        linker_callback()) — nunca se fuerzan a int().
      - [tipo, longitud]: arreglo — length siempre se fuerza a int, el
        tipo base se resuelve recursivamente (puede ser a su vez otro
        struct/union o un Ptr, para arreglos de structs o de punteros).
      - None: "inferir en cada llamada" (solo tiene sentido dentro de
        arg_types de define()).
    NUNCA se fuerza todo a int() a ciegas — eso rompía structs/arreglos
    (y ahora también rompería Ptr/Out/Callback/valores marcados).
    """
    if t is None:
        return None

    # Si el intérprete envolvió el valor en su NativeObjectValue genérico
    # (pasa con cualquier objeto devuelto por una llamada nativa que no
    # sea uno de sus tipos reconocidos, como Callback/Ptr/Out), lo
    # desenvolvemos usando la propiedad pública 'native_obj' que ese
    # wrapper expone. Se detecta por duck typing para no depender de
    # interpre.py.
    native = getattr(t, 'native_obj', None)
    if native is not None:
        t = native

    if isinstance(t, (Ptr, Out, Callback)):
        return t
    if isinstance(t, str):
        return t
    if isinstance(t, (list, tuple)):
        return (_coerce_type_spec(t[0]), int(t[1]))
    kind = getattr(t, '_ffi_kind', None)
    if kind is not None:
        tc = _FFI_KIND_TO_LINKER.get(kind)
        if tc is not None:
            return tc
    return int(t)


def linker_obj_vr(bridge, var_name: str, type_code=None, length=None) -> Any:
    tc = _coerce_type_spec(type_code) if type_code is not None else None
    return bridge.get_var(str(var_name), tc, int(length) if length else None)


def linker_obj_set(bridge, var_name: str, value: Any, type_code=None, length=None):
    tc = _coerce_type_spec(type_code) if type_code is not None else None
    bridge.set_var(str(var_name), value, tc, int(length) if length else None)


def linker_obj_definevar(bridge, var_name: str, type_code, length=None) -> None:
    bridge.define_var(str(var_name), _coerce_type_spec(type_code), int(length) if length else None)


def linker_obj_definestruct(bridge, struct_name: str, fields, pack=None, as_tuple=False) -> None:
    """
    fields: lista de [nombre_campo, tipo, longitud?, bits?] — 'tipo' puede
    ser primitivo, el nombre de otro struct/union ya declarado (anidado),
    o un Ptr(...) (campo puntero tipado).
    """
    norm = []
    for f in fields:
        fname = f[0]
        ftype = _coerce_type_spec(f[1])
        flen  = int(f[2]) if len(f) > 2 and f[2] else None
        fbits = int(f[3]) if len(f) > 3 and f[3] else None
        norm.append((fname, ftype, flen, fbits))
    bridge.define_struct(str(struct_name), norm,
                          pack=int(pack) if pack else None,
                          as_tuple=bool(as_tuple))


def linker_obj_defineunion(bridge, union_name: str, fields, pack=None, as_tuple=False) -> None:
    """Igual que linker_obj_definestruct() pero arma un union en vez de un struct."""
    norm = []
    for f in fields:
        fname = f[0]
        ftype = _coerce_type_spec(f[1])
        flen  = int(f[2]) if len(f) > 2 and f[2] else None
        fbits = int(f[3]) if len(f) > 3 and f[3] else None
        norm.append((fname, ftype, flen, fbits))
    bridge.define_union(str(union_name), norm,
                         pack=int(pack) if pack else None,
                         as_tuple=bool(as_tuple))


def linker_obj_define(bridge, func_name: str, ret_type, types, variadic=False) -> None:
    if not isinstance(types, list):
        types = [types]
    bridge.define(str(func_name), _coerce_type_spec(ret_type),
                  [_coerce_type_spec(t) for t in types], variadic=bool(variadic))


def linker_obj_getheader(bridge_obj, path) -> dict:
    p = Path(str(path))
    if not p.exists():
        raise LinkerError(f"getHeader(): no existe '{path}'.")
    return scan_c_header(p)


def linker_obj_lasterror(bridge) -> dict:
    if not hasattr(bridge, 'last_error'):
        raise LinkerError("lastError() solo aplica a librerías precompiladas (.so/.dll/.dylib).")
    return bridge.last_error()


def linker_obj_unload(bridge) -> None:
    bridge.unload()


# ════════════════════════════════════════════════════════════════════════
#  NATIVE_MODULE — descriptor leido por module_loader.py
# ════════════════════════════════════════════════════════════════════════

NATIVE_MODULE = {
    "module": "linker",

    "bridge_functions": {
        "__linker_load":            lambda args, _: linker_load(*args),
        "__linker_load_deps":       lambda args, _: linker_load_deps(*args),
        "__linker_create":          lambda args, _: linker_create(*args),
        "__linker_ptr":             lambda args, _: linker_ptr(*args),
        "__linker_out":             lambda args, _: linker_out(*args),
        "__linker_obj_fn":          lambda args, _: linker_obj_fn(*args),
        "__linker_native_callback_fn": lambda args, _: linker_native_callback_fn(*args),
        "__linker_obj_vr":          lambda args, _: linker_obj_vr(*args),
        "__linker_obj_set":         lambda args, _: linker_obj_set(*args),
        "__linker_obj_definevar":   lambda args, _: linker_obj_definevar(*args),
        "__linker_obj_definestruct":lambda args, _: linker_obj_definestruct(*args),
        "__linker_obj_defineunion": lambda args, _: linker_obj_defineunion(*args),
        "__linker_obj_define":      lambda args, _: linker_obj_define(*args),
        "__linker_obj_getheader":   lambda args, _: linker_obj_getheader(*args),
        "__linker_obj_lasterror":   lambda args, _: linker_obj_lasterror(*args),
        "__linker_obj_unload":      lambda args, _: linker_obj_unload(*args),
    },

    "functions": {
        "load":             lambda args, interp: linker_load(*args),
        "loadDependencies":  lambda args, interp: linker_load_deps(*args),
        "ptr":               lambda args, interp: linker_ptr(*args),
        "out":               lambda args, interp: linker_out(*args),
        "aligned":           lambda args, interp: linker_aligned(*args),
        "callbackSignature": lambda args, interp: linker_callback_signature(*args),
        "callback":          lambda args, interp: linker_callback(*args),
    },

    "exports": {
        "INT":         lambda: LINKER_INT,
        "FLOAT":       lambda: LINKER_FLOAT,
        "STRING":      lambda: LINKER_STRING,
        "WSTRING":     lambda: LINKER_WSTRING,
        "POINTER":     lambda: LINKER_POINTER,
        "VOID":        lambda: LINKER_VOID,
        "BOOL":        lambda: LINKER_BOOL,
        # NO se exportan INT8/16/32/64, UINT8..64, FLOAT32, LONGDOUBLE como
        # constantes con nombre — esos anchos se piden desde Tesseract con
        # los atributos por tipo (x._int32, y._float32, etc., ver el bloque
        # de atributos FFI en interpre.py), nunca como una constante nueva
        # del modulo. Los codigos LINKER_INT8.._LONGDOUBLE siguen existiendo
        # PY INTERNAMENTE en este archivo — los usa el mapeo _FFI_KIND_TO_LINKER
        # para traducir esos atributos, y quedan disponibles para quien
        # llame a este bridge directamente desde Python — pero no se
        # exponen como identificadores nuevos dentro del lenguaje.
    },

    "classes": {
        "LinkerObject": LinkerObject,
        "NativeCallback": NativeCallback,
    },
}