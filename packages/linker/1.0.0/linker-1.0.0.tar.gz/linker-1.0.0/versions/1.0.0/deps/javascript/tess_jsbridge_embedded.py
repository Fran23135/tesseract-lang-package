"""
tess_jsbridge_embedded.py
=========================
Micro-motor JavaScript EMBEBIDO para el linker de Tesseract.
Usa el paquete 'quickjs' que incluye el motor QuickJS compilado —
NO necesita Node.js instalado en el sistema.

Instalación (ya listado en specs.tlib):
    pip install quickjs

API pública (igual que tess_jsbridge.js pero en-proceso):
    El módulo JS debe exportar funciones y variables via el objeto global.
    Ejemplo:
        function sqrt(x) { return Math.sqrt(x); }
        var PI = 3.14159;
"""

import json
import sys
import os
from pathlib import Path


def _load_quickjs():
    try:
        import quickjs
        return quickjs
    except ImportError:
        sys.stderr.write(
            "[linker/js] quickjs no instalado.\n"
            "  pip install quickjs\n"
        )
        sys.exit(1)


class JSBridgeEmbedded:
    """Motor JS en-proceso via QuickJS. No usa subproceso."""

    def __init__(self):
        qjs        = _load_quickjs()
        self._ctx  = qjs.Context()
        self._path = None

    def load(self, path: str):
        self._path = Path(path).resolve()
        if not self._path.exists():
            raise FileNotFoundError(f"Archivo JS no encontrado: {path}")
        code = self._path.read_text(encoding='utf-8')
        # Inyectar el directorio del script en el scope para búsquedas relativas
        dir_js = str(self._path.parent).replace('\\', '\\\\')
        self._ctx.eval(f"var __dirname = '{dir_js}';")
        self._ctx.eval(code)

    def call(self, func_name: str, args: list):
        fn = self._ctx.eval(func_name)
        if not callable(fn):
            raise TypeError(f"'{func_name}' no es una función en el módulo JS")
        result = fn(*args)
        # quickjs puede retornar objetos JS — convertir a Python básico
        return self._to_python(result)

    def get(self, var_name: str):
        val = self._ctx.eval(var_name)
        return self._to_python(val)

    def set(self, var_name: str, value):
        self._ctx.eval(f"var {var_name} = {json.dumps(value)};")

    def _to_python(self, val):
        """Convierte valor QuickJS a tipo Python básico."""
        if val is None:                  return None
        if isinstance(val, (bool, int,
                            float, str)): return val
        # Intentar serializar via JSON para objetos/arrays JS
        try:
            import quickjs
            if isinstance(val, quickjs.Object):
                raw = self._ctx.eval("JSON.stringify(_tess_tmp_)")
                self._ctx.eval("var _tess_tmp_ = undefined;")
                return json.loads(raw) if raw else None
        except Exception:
            pass
        return str(val)


# ── Modo línea de comandos (para pruebas directas) ────────────────────

def main():
    engine = JSBridgeEmbedded()

    def respond(data):
        sys.stdout.write(json.dumps(data, ensure_ascii=False, default=str) + '\n')
        sys.stdout.flush()

    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            cmd    = json.loads(raw)
            action = cmd.get('action', '')

            if action == 'load':
                engine.load(cmd['path'])
                respond({'ok': True})

            elif action == 'call':
                result = engine.call(cmd.get('func', ''), cmd.get('args', []))
                respond({'ok': True, 'result': result})

            elif action == 'get':
                result = engine.get(cmd.get('var', ''))
                respond({'ok': True, 'result': result})

            elif action == 'set':
                engine.set(cmd.get('var', ''), cmd.get('value'))
                respond({'ok': True})

            elif action == 'unload':
                respond({'ok': True})
                break

            else:
                respond({'ok': False, 'error': f"Acción desconocida: '{action}'"})

        except json.JSONDecodeError as e:
            respond({'ok': False, 'error': f"JSON inválido: {e}"})
        except Exception as e:
            import traceback
            respond({'ok': False, 'error': traceback.format_exc(limit=5).strip()})


if __name__ == '__main__':
    main()
