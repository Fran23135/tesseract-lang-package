"""
linker_bridge.py
================
Implementación nativa Python del módulo linker de Tesseract.

RUTAS DE EJECUCIÓN:
  .so / .dll / .dylib  → _FFIBridge     (ctypes en-proceso, libffi incluida en Python)
  .py                  → _PyBridge      (importlib en-proceso, portable)
  .js                  → _JSBridge      (quickjs embebido, sin Node.js requerido)
                          fallback:      subprocess con tess_jsbridge.js si hay Node.js
  .lua                 → _LuaBridge     (lupa/LuaJIT embebido, sin Lua requerido)
                          fallback:      subprocess con tess_luabridge.lua si hay Lua

DEPENDENCIAS (specs.tlib → dependencies.native):
  quickjs  →  pip install quickjs   (motor JS embebido, portable)
  lupa     →  pip install lupa      (LuaJIT embebido, portable)
"""

import ctypes
import importlib.util
import json
import os
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any

# ── Directorio de deps (este archivo ESTÁ en deps/) ───────────────────
_DEPS_DIR = Path(__file__).parent

# ── Constantes de tipo ────────────────────────────────────────────────
LINKER_INT     = 0
LINKER_FLOAT   = 1
LINKER_STRING  = 2
LINKER_POINTER = 3
LINKER_VOID    = 4

_CTYPE_MAP = {
    LINKER_INT:     ctypes.c_int64,
    LINKER_FLOAT:   ctypes.c_double,
    LINKER_STRING:  ctypes.c_char_p,
    LINKER_POINTER: ctypes.c_void_p,
    LINKER_VOID:    None,
}

_FFI_EXTS = {'.so', '.dll', '.dylib'}


class LinkerError(RuntimeError):
    pass


# ════════════════════════════════════════════════════════════════════════
#  Bridges internos — uno por tipo de archivo
# ════════════════════════════════════════════════════════════════════════

class _FFIBridge:
    """Bridge para binarios compilados (.so / .dll / .dylib) via ctypes."""

    def __init__(self, path: Path):
        self._path = path
        self._sigs = {}
        try:
            self._lib = ctypes.CDLL(str(path))
        except OSError as e:
            raise LinkerError(
                f"Error FFI cargando '{path.name}':\n  {e}\n"
                f"  ¿Compilado para la arquitectura correcta?"
            )

    def call(self, func_name: str, args: list) -> Any:
        try:
            fn = getattr(self._lib, func_name)
        except AttributeError:
            raise LinkerError(
                f"Símbolo '{func_name}' no encontrado en '{self._path.name}'.\n"
                f"  Asegúrate de exportarlo con extern \"C\" en C++."
            )
        if func_name in self._sigs:
            ret_code, arg_codes = self._sigs[func_name]
            fn.restype  = _CTYPE_MAP.get(ret_code)
            fn.argtypes = [_CTYPE_MAP[c] for c in arg_codes if _CTYPE_MAP.get(c)]
        try:
            result = fn(*[_to_c(a) for a in args])
            return _from_c(result)
        except ctypes.ArgumentError as e:
            raise LinkerError(f"Error de tipos en '{func_name}': {e}")

    def get_var(self, var_name: str) -> Any:
        try:
            sym = getattr(self._lib, var_name)
            return sym.value if hasattr(sym, 'value') else sym
        except AttributeError:
            raise LinkerError(f"Variable '{var_name}' no encontrada en '{self._path.name}'")

    def set_var(self, var_name: str, value: Any):
        try:
            sym = getattr(self._lib, var_name)
            sym.value = value
        except AttributeError:
            raise LinkerError(f"Variable '{var_name}' no encontrada en '{self._path.name}'")

    def define(self, func_name: str, ret_type: int, arg_types: list):
        self._sigs[func_name] = (int(ret_type), [int(t) for t in arg_types])

    def unload(self):
        if self._lib:
            try:
                handle = self._lib._handle
                if sys.platform == 'win32':
                    ctypes.windll.kernel32.FreeLibrary(handle)
                else:
                    try:
                        libdl = ctypes.CDLL("libdl.so.2")
                    except OSError:
                        libdl = ctypes.CDLL(None)
                    libdl.dlclose(handle)
            except Exception:
                pass
            finally:
                self._lib = None


class _PyBridge:
    """Bridge para scripts Python (.py) via importlib — sin subproceso."""

    def __init__(self, path: Path):
        self._path = path
        spec = importlib.util.spec_from_file_location("_tess_py_ext", str(path))
        if spec is None:
            raise LinkerError(f"No se pudo cargar el módulo Python: {path}")
        self._mod = importlib.util.module_from_spec(spec)
        # Añadir el directorio del script al sys.path para sus imports
        script_dir = str(path.parent)
        if script_dir not in sys.path:
            sys.path.insert(0, script_dir)
        spec.loader.exec_module(self._mod)

    def call(self, func_name: str, args: list) -> Any:
        fn = getattr(self._mod, func_name, None)
        if fn is None or not callable(fn):
            raise LinkerError(f"'{func_name}' no existe o no es callable en '{self._path.name}'")
        return fn(*args)

    def get_var(self, var_name: str) -> Any:
        if not hasattr(self._mod, var_name):
            raise LinkerError(f"Variable '{var_name}' no encontrada en '{self._path.name}'")
        return getattr(self._mod, var_name)

    def set_var(self, var_name: str, value: Any):
        setattr(self._mod, var_name, value)

    def define(self, func_name, ret_type, arg_types):
        pass  # Python tiene tipado dinámico, define() no aplica

    def unload(self):
        self._mod = None


class _JSBridge:
    """
    Bridge para scripts JavaScript (.js).
    Prioridad:
      1. quickjs (embebido, portable, sin Node.js)
      2. subprocess con Node.js si está en PATH (fallback)
    """

    def __init__(self, path: Path):
        self._path = path
        self._lock = threading.Lock()

        # Intentar motor embebido (quickjs)
        try:
            from deps.javascript.tess_jsbridge_embedded import JSBridgeEmbedded
            self._engine = JSBridgeEmbedded()
            self._mode   = 'embedded'
        except (ImportError, ModuleNotFoundError):
            try:
                # Fallback: cargar tess_jsbridge_embedded desde la ruta de deps
                spec = importlib.util.spec_from_file_location(
                    "_tess_jsbridge",
                    str(_DEPS_DIR / "javascript" / "tess_jsbridge_embedded.py")
                )
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                self._engine = mod.JSBridgeEmbedded()
                self._mode   = 'embedded'
            except Exception:
                # Último fallback: subprocess con Node.js
                self._engine = _SubprocessBridge(
                    path,
                    cmd=['node', str(_DEPS_DIR / 'javascript' / 'tess_jsbridge.js')],
                    runtime_name='Node.js (https://nodejs.org)',
                )
                self._mode = 'subprocess'

        self._engine.load(str(path))

    def call(self, func_name: str, args: list) -> Any:
        with self._lock:
            return self._engine.call(func_name, args)

    def get_var(self, var_name: str) -> Any:
        with self._lock:
            return self._engine.get(var_name)

    def set_var(self, var_name: str, value: Any):
        with self._lock:
            self._engine.set(var_name, value)

    def define(self, func_name, ret_type, arg_types):
        pass  # JS tiene tipado dinámico

    def unload(self):
        if hasattr(self._engine, 'unload'):
            self._engine.unload()


class _LuaBridge:
    """
    Bridge para scripts Lua (.lua).
    Prioridad:
      1. lupa (LuaJIT embebido, portable, sin Lua instalado)
      2. subprocess con Lua si está en PATH (fallback)
    """

    def __init__(self, path: Path):
        self._path = path
        self._lock = threading.Lock()

        try:
            spec = importlib.util.spec_from_file_location(
                "_tess_luabridge",
                str(_DEPS_DIR / "lua" / "tess_luabridge_embedded.py")
            )
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            self._engine = mod.LuaBridgeEmbedded()
            self._mode   = 'embedded'
        except Exception:
            # Fallback: subprocess con Lua del sistema
            self._engine = _SubprocessBridge(
                path,
                cmd=['lua', str(_DEPS_DIR / 'lua' / 'tess_luabridge.lua')],
                runtime_name='Lua 5.4 + lua-cjson (https://www.lua.org)',
            )
            self._mode = 'subprocess'

        self._engine.load(str(path))

    def call(self, func_name: str, args: list) -> Any:
        with self._lock:
            return self._engine.call(func_name, args)

    def get_var(self, var_name: str) -> Any:
        with self._lock:
            return self._engine.get(var_name)

    def set_var(self, var_name: str, value: Any):
        with self._lock:
            self._engine.set(var_name, value)

    def define(self, func_name, ret_type, arg_types):
        pass

    def unload(self):
        if hasattr(self._engine, 'unload'):
            self._engine.unload()


class _SubprocessBridge:
    """
    Bridge genérico via subprocess JSON (fallback cuando los embebidos no están).
    Usado como último recurso para JS (Node.js) y Lua (sistema).
    """

    def __init__(self, path: Path, cmd: list, runtime_name: str):
        self._path = path
        self._lock = threading.Lock()
        try:
            self._proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True, bufsize=1,
            )
        except FileNotFoundError:
            raise LinkerError(
                f"Runtime no encontrado para '{path.name}'.\n"
                f"  Instala: {runtime_name}\n"
                f"  O instala el paquete Python embebido: pip install quickjs (JS) / lupa (Lua)"
            )

    def load(self, path: str):
        resp = self._ipc({'action': 'load', 'path': path})
        if not resp.get('ok'):
            raise LinkerError(f"Error cargando: {resp.get('error')}")

    def call(self, func_name: str, args: list) -> Any:
        resp = self._ipc({'action': 'call', 'func': func_name, 'args': args})
        if not resp.get('ok'):
            raise LinkerError(f"Error en '{func_name}': {resp.get('error')}")
        return resp.get('result')

    def get(self, var_name: str) -> Any:
        resp = self._ipc({'action': 'get', 'var': var_name})
        if not resp.get('ok'):
            raise LinkerError(f"No se pudo leer '{var_name}': {resp.get('error')}")
        return resp.get('result')

    def set(self, var_name: str, value: Any):
        resp = self._ipc({'action': 'set', 'var': var_name, 'value': value})
        if not resp.get('ok'):
            raise LinkerError(f"No se pudo escribir '{var_name}': {resp.get('error')}")

    def unload(self):
        try:
            self._ipc({'action': 'unload'})
            self._proc.stdin.close()
            self._proc.wait(timeout=3)
        except Exception:
            try:
                self._proc.kill()
            except Exception:
                pass

    def _ipc(self, cmd: dict) -> dict:
        with self._lock:
            self._proc.stdin.write(json.dumps(cmd) + '\n')
            self._proc.stdin.flush()
            line = self._proc.stdout.readline()
        if not line:
            raise LinkerError("Subproceso IPC cerró inesperadamente.")
        return json.loads(line.strip())


# ════════════════════════════════════════════════════════════════════════
#  Helpers de conversión FFI
# ════════════════════════════════════════════════════════════════════════

def _to_c(val: Any):
    if isinstance(val, bool):  return ctypes.c_int(int(val))
    if isinstance(val, int):   return ctypes.c_int64(val)
    if isinstance(val, float): return ctypes.c_double(val)
    if isinstance(val, str):   return val.encode('utf-8')
    return val

def _from_c(val: Any) -> Any:
    if val is None:             return None
    if isinstance(val, bytes):  return val.decode('utf-8', errors='replace')
    return val


# ════════════════════════════════════════════════════════════════════════
#  LinkerObject — objeto de conexión viva retornado por linker.load()
# ════════════════════════════════════════════════════════════════════════

class LinkerObject:
    """
    Objeto retornado por linker.load(path).
    Representa el puente activo con el código externo.

    Métodos:
        .func(nombre, arg1, arg2, ...)  ejecuta función externa
        .var(nombre)                    lee variable global externa
        .set(nombre, valor)             escribe variable global externa
        .define(nombre, ret, tipos)     fija firma FFI exacta (solo FFI)
        .unload()                       destruye el puente y libera recursos
    """

    def __init__(self, path: str):
        p   = Path(path).resolve()
        ext = p.suffix.lower()

        if ext in _FFI_EXTS:
            self._bridge = _FFIBridge(p)
        elif ext == '.py':
            self._bridge = _PyBridge(p)
        elif ext == '.js':
            self._bridge = _JSBridge(p)
        elif ext == '.lua':
            self._bridge = _LuaBridge(p)
        elif ext == '.o':
            raise LinkerError(
                f"Los .o no se cargan directamente. Compila primero:\n"
                f"  Linux/macOS: gcc -shared -fPIC {p.name} -o lib{p.stem}.so\n"
                f"  Windows:     cl /LD {p.name} /Fe:{p.stem}.dll"
            )
        elif ext == '.c':
            raise LinkerError(
                f"Los .c no se cargan directamente. Compila primero:\n"
                f"  Linux/macOS: gcc -shared -fPIC -O2 {p.name} -o lib{p.stem}.so\n"
                f"  Windows:     cl /LD {p.name} /Fe:{p.stem}.dll"
            )
        else:
            raise LinkerError(
                f"Extensión '{ext}' no soportada.\n"
                f"  FFI (binario): .so  .dll  .dylib\n"
                f"  IPC/embebido:  .py  .js  .lua"
            )

        self._path   = p
        self._loaded = True

    # ── API pública ───────────────────────────────────────────────────

    def func(self, func_name, *args):
        """
        Ejecuta una función en el código externo.
        Acepta:  obj.func("nombre", arg1, arg2)
                 obj.func("nombre", [arg1, arg2])   (cuando el intérprete pasa lista)
        """
        self._check()
        # Normalizar args: el intérprete Tesseract puede pasar lista única
        if len(args) == 1 and isinstance(args[0], list):
            args = args[0]
        else:
            args = list(args)
        return self._bridge.call(str(func_name), args)

    def var(self, var_name):
        """Lee el valor de una variable global del código externo."""
        self._check()
        return self._bridge.get_var(str(var_name))

    def set(self, var_name, value):
        """Sobrescribe una variable global en el código externo."""
        self._check()
        self._bridge.set_var(str(var_name), value)

    def define(self, func_name, ret_type, types):
        """
        Fija la firma de tipos para FFI preciso.
        Solo aplica a módulos FFI (.so/.dll/.dylib).

        Ejemplo:
            obj.define("render", linker.POINTER, [linker.INT, linker.INT])
        """
        self._check()
        if not isinstance(types, list):
            types = [types]
        self._bridge.define(str(func_name), int(ret_type), [int(t) for t in types])

    def unload(self):
        """Destruye el puente y libera todos los recursos del SO."""
        if self._loaded:
            self._bridge.unload()
            self._loaded = False

    def _check(self):
        if not self._loaded:
            raise LinkerError(
                "LinkerObject no está activo. ¿Llamaste unload() antes de tiempo?"
            )

    def __repr__(self):
        return (
            f"<LinkerObject path='{self._path.name}' "
            f"bridge={type(self._bridge).__name__} loaded={self._loaded}>"
        )

    def __del__(self):
        if getattr(self, '_loaded', False):
            try:
                self.unload()
            except Exception:
                pass


# ════════════════════════════════════════════════════════════════════════
#  Funciones globales del módulo
# ════════════════════════════════════════════════════════════════════════

def linker_load(path: str) -> LinkerObject:
    """
    linker.load(path) — Punto de entrada principal.
    Detecta la extensión y elige el bridge correcto automáticamente.
    Retorna un LinkerObject listo para operar.
    """
    return LinkerObject(path)


def linker_load_deps(path: str) -> None:
    """
    linker.loadDependencies(path)
    Configura el directorio de dependencias para scripts externos.
    Debe llamarse ANTES de linker.load().
    """
    p = Path(path)
    if not p.exists():
        raise LinkerError(f"Directorio de dependencias no encontrado: {path}")
    dep_str = str(p.resolve())
    os.environ['TESS_LINKER_DEPS'] = dep_str
    sys.path.insert(0, dep_str)
    os.environ['NODE_PATH'] = dep_str + os.pathsep + os.environ.get('NODE_PATH', '')


# ════════════════════════════════════════════════════════════════════════
#  NATIVE_MODULE — descriptor para module_loader
# ════════════════════════════════════════════════════════════════════════

NATIVE_MODULE = {
    "module": "linker",

    # Funciones pre-registradas en el intérprete aislado como __linker_*
    # El bytecode linker.tbc las llama internamente.
    "bridge_functions": {
        "__linker_load":      lambda args, _: linker_load(*args),
        "__linker_load_deps": lambda args, _: linker_load_deps(*args),
    },

    # Interfaz pública visible para module_loader.get_function()
    "functions": {
        "load":             lambda args, interp: linker_load(*args),
        "loadDependencies": lambda args, interp: linker_load_deps(*args),
    },

    # Constantes de tipo (linker.INT, linker.FLOAT, etc.)
    "exports": {
        "INT":     lambda: LINKER_INT,
        "FLOAT":   lambda: LINKER_FLOAT,
        "STRING":  lambda: LINKER_STRING,
        "POINTER": lambda: LINKER_POINTER,
        "VOID":    lambda: LINKER_VOID,
    },

    # Clase LinkerObject — registrada en el module_loader para OOP
    # Las instancias retornadas por linker.load() son de este tipo.
    # El intérprete accede a sus métodos via atributos Python directamente.
    "classes": {
        "LinkerObject": LinkerObject,
    },
}


# ════════════════════════════════════════════════════════════════════════
#  Funciones bridge para los métodos de LinkerObject
#  Pre-registradas como __linker_create, __linker_obj_fn, etc.
#  El bytecode code.tss las llama internamente desde los métodos
#  de la clase LinkerObject en Tesseract.
# ════════════════════════════════════════════════════════════════════════

def linker_create(path: str):
    """
    __linker_create(path) — crea el bridge interno sin el wrapper Python.
    El Tesseract LinkerObject guarda este bridge en this._bridge.
    Retorna directamente el bridge (_FFIBridge, _PyBridge, _JSBridge, _LuaBridge).
    """
    p   = Path(path).resolve()
    ext = p.suffix.lower()

    if not p.exists():
        raise LinkerError(f"Archivo no encontrado: {p}")

    if ext in _FFI_EXTS:
        return _FFIBridge(p)
    elif ext == '.py':
        return _PyBridge(p)
    elif ext == '.js':
        b = _JSBridge.__new__(_JSBridge)
        b._path = p
        b._lock = threading.Lock()
        try:
            import importlib.util as _ilu
            spec = _ilu.spec_from_file_location(
                "_tess_jsbridge",
                str(_DEPS_DIR / "javascript" / "tess_jsbridge_embedded.py")
            )
            mod = _ilu.module_from_spec(spec)
            spec.loader.exec_module(mod)
            b._engine = mod.JSBridgeEmbedded()
            b._mode   = 'embedded'
        except Exception:
            b._engine = _SubprocessBridge(
                p,
                cmd=['node', str(_DEPS_DIR / 'javascript' / 'tess_jsbridge.js')],
                runtime_name='Node.js (https://nodejs.org)',
            )
            b._mode = 'subprocess'
        b._engine.load(str(p))
        return b
    elif ext == '.lua':
        b = _LuaBridge.__new__(_LuaBridge)
        b._path = p
        b._lock = threading.Lock()
        try:
            import importlib.util as _ilu
            spec = _ilu.spec_from_file_location(
                "_tess_luabridge",
                str(_DEPS_DIR / "lua" / "tess_luabridge_embedded.py")
            )
            mod = _ilu.module_from_spec(spec)
            spec.loader.exec_module(mod)
            b._engine = mod.LuaBridgeEmbedded()
            b._mode   = 'embedded'
        except Exception:
            b._engine = _SubprocessBridge(
                p,
                cmd=['lua', str(_DEPS_DIR / 'lua' / 'tess_luabridge.lua')],
                runtime_name='Lua 5.4 (https://www.lua.org)',
            )
            b._mode = 'subprocess'
        b._engine.load(str(p))
        return b
    elif ext == '.o':
        raise LinkerError(
            f"Los .o no se cargan directamente.\n"
            f"  Linux/macOS: gcc -shared -fPIC {p.name} -o lib{p.stem}.so\n"
            f"  Windows:     cl /LD {p.name} /Fe:{p.stem}.dll"
        )
    elif ext == '.c':
        raise LinkerError(
            f"Los .c no se cargan directamente.\n"
            f"  Linux/macOS: gcc -shared -fPIC -O2 {p.name} -o lib{p.stem}.so\n"
            f"  Windows:     cl /LD {p.name} /Fe:{p.stem}.dll"
        )
    else:
        raise LinkerError(
            f"Extensión '{ext}' no soportada.\n"
            f"  FFI:       .so  .dll  .dylib\n"
            f"  Embebido:  .py  .js  .lua"
        )


def linker_obj_fn(bridge, func_name: str, *args) -> Any:
    """
    __linker_obj_fn(bridge, name, arg1, arg2, ...)
    Ejecuta una función en el código externo.
    Tesseract llama esto desde LinkerObject.fn()
    """
    # Normalizar args: el intérprete puede pasar lista o varargs
    if len(args) == 1 and isinstance(args[0], list):
        args = args[0]
    else:
        args = list(args)
    return bridge.call(str(func_name), args)


def linker_obj_vr(bridge, var_name: str) -> Any:
    """
    __linker_obj_vr(bridge, name)
    Lee variable global. Tesseract llama esto desde LinkerObject.vr()
    ('vr' para evitar conflicto con keyword 'var' de Tesseract)
    """
    return bridge.get_var(str(var_name))


def linker_obj_set(bridge, var_name: str, value: Any):
    """
    __linker_obj_set(bridge, name, value)
    Escribe variable global. Tesseract llama esto desde LinkerObject.set()
    """
    bridge.set_var(str(var_name), value)


def linker_obj_define(bridge, func_name: str, ret_type, types) -> None:
    """
    __linker_obj_define(bridge, name, ret_type, types)
    Fija firma FFI. Tesseract llama esto desde LinkerObject.define()
    """
    if not isinstance(types, list):
        types = [types]
    bridge.define(str(func_name), int(ret_type), [int(t) for t in types])


def linker_obj_unload(bridge) -> None:
    """
    __linker_obj_unload(bridge)
    Destruye el puente. Tesseract llama esto desde LinkerObject.unload()
    """
    bridge.unload()


# ════════════════════════════════════════════════════════════════════════
#  Actualizar NATIVE_MODULE con todos los bridge functions
# ════════════════════════════════════════════════════════════════════════

NATIVE_MODULE = {
    "module": "linker",

    # ── Funciones pre-registradas en el intérprete aislado ────────────────
    # El bytecode linker.tbc las invoca internamente desde las funciones
    # y métodos de clase declarados en code.tss.
    "bridge_functions": {
        # Módulo nivel
        "__linker_load":         lambda args, _: linker_load(*args),
        "__linker_load_deps":    lambda args, _: linker_load_deps(*args),
        # Creación del bridge interno (guardado en this._bridge del objeto Tesseract)
        "__linker_create":       lambda args, _: linker_create(*args),
        # Métodos de instancia — despachan al bridge interno
        "__linker_obj_fn":       lambda args, _: linker_obj_fn(*args),
        "__linker_obj_vr":       lambda args, _: linker_obj_vr(*args),
        "__linker_obj_set":      lambda args, _: linker_obj_set(*args),
        "__linker_obj_define":   lambda args, _: linker_obj_define(*args),
        "__linker_obj_unload":   lambda args, _: linker_obj_unload(*args),
    },

    # ── Interfaz pública del módulo ───────────────────────────────────────
    "functions": {
        "load":             lambda args, interp: linker_load(*args),
        "loadDependencies": lambda args, interp: linker_load_deps(*args),
    },

    # ── Constantes de tipo ────────────────────────────────────────────────
    "exports": {
        "INT":     lambda: LINKER_INT,
        "FLOAT":   lambda: LINKER_FLOAT,
        "STRING":  lambda: LINKER_STRING,
        "POINTER": lambda: LINKER_POINTER,
        "VOID":    lambda: LINKER_VOID,
    },

    # ── Clase LinkerObject — registrada para OOP ──────────────────────────
    "classes": {
        "LinkerObject": LinkerObject,
    },
}
