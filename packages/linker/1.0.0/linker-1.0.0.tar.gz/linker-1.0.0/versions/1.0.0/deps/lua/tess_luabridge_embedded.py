"""
tess_luabridge_embedded.py
==========================
Micro-motor Lua EMBEBIDO para el linker de Tesseract.
Usa el paquete 'lupa' que incluye LuaJIT compilado —
NO necesita Lua instalado en el sistema.

Instalación (ya listado en specs.tlib):
    pip install lupa

API pública (igual que tess_luabridge.lua pero en-proceso):
    El módulo Lua define funciones y variables en su scope global.
    Ejemplo:
        PI = 3.14159
        function sqrt(x) return math.sqrt(x) end
"""

import json
import sys
from pathlib import Path


def _load_lupa():
    try:
        import lupa
        return lupa
    except ImportError:
        sys.stderr.write(
            "[linker/lua] lupa no instalado.\n"
            "  pip install lupa\n"
        )
        sys.exit(1)


class LuaBridgeEmbedded:
    """Motor Lua en-proceso via LuaJIT (lupa). No usa subproceso."""

    def __init__(self):
        lupa      = _load_lupa()
        self._lua = lupa.LuaRuntime(unpack_returned_tuples=True)
        self._path = None
        # Habilitar librerías estándar de Lua
        self._lua.execute("require('math')")
        self._lua.execute("require('string')")
        self._lua.execute("require('table')")

    def load(self, path: str):
        self._path = Path(path).resolve()
        if not self._path.exists():
            raise FileNotFoundError(f"Archivo Lua no encontrado: {path}")
        code = self._path.read_text(encoding='utf-8')
        self._lua.execute(code)

    def call(self, func_name: str, args: list):
        fn = self._lua.eval(func_name)
        if not callable(fn):
            raise TypeError(f"'{func_name}' no es una función en el módulo Lua")
        result = fn(*args)
        return self._to_python(result)

    def get(self, var_name: str):
        val = self._lua.eval(var_name)
        return self._to_python(val)

    def set(self, var_name: str, value):
        self._lua.globals()[var_name] = value

    def _to_python(self, val):
        """Convierte valor Lua a tipo Python básico."""
        if val is None:                       return None
        if isinstance(val, (bool, int,
                            float, str)):      return val
        # Tabla Lua → dict o list Python
        try:
            import lupa
            if lupa.lua_type(val) == 'table':
                # Intentar como lista (índices 1..n)
                try:
                    items = [self._to_python(val[i]) for i in range(1, len(val) + 1)]
                    return items
                except Exception:
                    pass
                # Intentar como dict
                try:
                    return {k: self._to_python(v) for k, v in val.items()}
                except Exception:
                    pass
        except Exception:
            pass
        return str(val)


# ── Modo línea de comandos (para pruebas directas) ────────────────────

def main():
    engine = LuaBridgeEmbedded()

    def respond(data):
        sys.stdout.write(json.dumps(data, ensure_ascii=False, default=str) + '\n')
        sys.stdout.flush()

    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            cmd    = json.loads(raw)
            action = cmd.get('action', '')

            if action == 'load':
                engine.load(cmd['path'])
                respond({'ok': True})

            elif action == 'call':
                result = engine.call(cmd.get('func', ''), cmd.get('args', []))
                respond({'ok': True, 'result': result})

            elif action == 'get':
                result = engine.get(cmd.get('var', ''))
                respond({'ok': True, 'result': result})

            elif action == 'set':
                engine.set(cmd.get('var', ''), cmd.get('value'))
                respond({'ok': True})

            elif action == 'unload':
                respond({'ok': True})
                break

            else:
                respond({'ok': False, 'error': f"Acción desconocida: '{action}'"})

        except json.JSONDecodeError as e:
            respond({'ok': False, 'error': f"JSON inválido: {e}"})
        except Exception as e:
            import traceback
            respond({'ok': False, 'error': traceback.format_exc(limit=5).strip()})


if __name__ == '__main__':
    main()
